# Ballot Integrity Subsystem (SR-13 to SR-16)

**Owner:** Muzammil Malek (s4175334)
**Part of:** Electronic Voting Platform group project

This subsystem implements the four requirements assigned to me, using the
solutions selected in Part 2.

| Req | What it does | Part 2 solution implemented | Status |
|---|---|---|---|
| SR-13 | One voter, one ballot authorization, nationwide | `SELECT … FOR UPDATE NOWAIT` in a `SERIALIZABLE` transaction, then a single-use RS256 token with no voter identity | Fully implemented |
| SR-14 | Signed vote batches and signed receipts | Ed25519 batch signature per terminal; Ed25519-signed receipt from the Ballot Store | **Partially** implemented: the terminal key is a software key behind a `TerminalSigner` interface, not a hardware TPM |
| SR-15 | Independent recount blocks a wrong result | Two engines (JavaScript and Python) with no shared code; publication gate; State Electoral Officer alert | Fully implemented |
| SR-16 | Keep voting through a network outage | AES-256-GCM encrypted, hash-chained SQLite queue; auto-forwarding with ≤2 min retry; 12 h cap | Fully implemented |

## Architecture

```
 Polling terminal (Node, 127.0.0.1:4100)              Central server (Express, :3000)
 ┌──────────────────────────────────┐                 ┌──────────────────────────────────────┐
 │ GUI (official + voter ballot)    │                 │ REST API  /api/...                   │
 │        │                         │  signed request │                                      │
 │ Local API ── authorize ──────────┼────────────────▶│ Mark-off Service (SR-13)             │
 │        │                         │ ◀── token ──────│   row lock + SERIALIZABLE            │──▶ roll schema
 │ OfflineQueue (SR-16)             │                 │                                      │
 │   AES-256-GCM, hash-chained,     │  signed batch   │ Ballot Store (SR-14, SR-16)          │
 │   SQLite on disk                 ├────────────────▶│   verify sig, chain, replay, token   │──▶ ballot schema
 │ SyncAgent ── retry/backoff ──────┤ ◀── signed ─────│   sign receipt (Ed25519)             │
 │ TerminalSigner (Ed25519)         │     receipt     │                                      │
 └──────────────────────────────────┘                 │ Tally gate (SR-15)                   │
                                                      │   Engine A (JS) ─┐ compare ─▶ publish│──▶ ops schema
 Officer console (/admin) ───────────────────────────▶│   Engine B (Py) ─┘   or BLOCK+alert  │
                                                      └──────────────────────────────────────┘
```

The `roll`, `ballot` and `ops` schemas each have their own connection pool
and connection string, so they can be split across separate database servers
and subnets (Caressa's SR-08) without code changes.

## Where each requirement lives in the code

| Req | Files |
|---|---|
| SR-13 | `server/src/markoff/service.js` (lock, transaction, token), `server/src/routes.js` (`POST /api/markoff/authorize`), `server/db/schema.sql` (`roll.electoral_roll`, `ballot.spent_tokens`) |
| SR-14 | `terminal/src/signer.js`, `terminal/src/sync.js` (`buildBatch`, `verifyReceipt`), `server/src/terminals/registry.js`, `server/src/ballotstore/service.js` |
| SR-15 | `docs/counting-rules.md` (the only shared artefact), `server/src/tally/engineA.js`, `tally-engine-b/engine_b.py`, `server/src/tally/gate.js`, `server/public/admin/` |
| SR-16 | `terminal/src/queue.js`, `terminal/src/sync.js`, `shared/canonical.js` (hash chain), `server/src/ballotstore/service.js` (`checkChain`, declaration mark-off) |

## Security design patterns used

- **Defence in depth:** double voting is blocked at the mark-off row lock, again by the single-use token table, and again by the unique `ballot_id`.
- **Privilege separation / data minimisation:** the roll knows *who* voted, the ballot store knows *what* was voted; the token links them but holds no voter ID, and the `jti` is never stored on the roll side.
- **N-version programming:** two independently written counting engines in different languages (SR-15).
- **Fail-secure:** lock contention, serialization failures, bad signatures, broken chains and engine disagreement all result in refusal, never a silent pass.
- **Secure logger (adapter):** every security event goes through `server/src/audit.js`, ready to point at Mmhachio's SR-09 hash-chained log.
- **Input allow-listing:** strict Zod schemas (`.strict()` rejects unknown fields), parameterised SQL only, candidate IDs restricted to `[A-Z0-9_-]`.
- **Security headers:** Helmet with a strict CSP (no inline scripts); GUIs render data with `textContent` only.
- **Idempotent, tamper-evident transport:** batches are saved before sending and resent byte-for-byte; the server returns the original receipt.

## Running it

**Requirements:** Node.js 22.13 or later, Python 3.10+, PostgreSQL 14+.

```bash
# 1. Database
createdb ballot_integrity            # or create it in pgAdmin

# 2. Server
cd ballot-integrity/server
cp .env.example .env                 # then edit the secrets and DATABASE_URL
npm install
npm run db:init -- --reset           # creates schema + 200 demo voters
npm start                            # http://localhost:3000/admin/

# 3. Terminal (second terminal window)
cd ballot-integrity/terminal
cp .env.example .env                 # set ENROLMENT_SECRET (same as server) and TERMINAL_QUEUE_KEY
npm install
npm start                            # http://127.0.0.1:4100
```

On Windows, `PYTHON_BIN=python` may be needed in the server's `.env`.

## Running the tests

```bash
# Server: needs PostgreSQL. Creates/uses the ballot_integrity_test database.
cd server && TEST_DATABASE_URL=postgres://postgres:postgres@localhost:5432/ballot_integrity_test npm test

# Terminal: no database needed
cd terminal && npm test

# Engine B (Python)
cd tally-engine-b && python3 -m unittest -v test_engine_b
```

57 tests in total: 39 server, 12 terminal, 6 Python. Highlights:

- 50 concurrent mark-off requests for one voter (also across 5 terminals over HTTP) produce exactly one token.
- `alg: none`, tampered and wrong-election tokens are rejected.
- Altered, unsigned, unknown-terminal and replayed batches are rejected; a lost receipt is recovered without double counting.
- Deleting a queued ballot breaks the hash chain and raises an alert.
- Queue ciphertext does not contain the ballot; tampering, row swapping and the wrong key are detected.
- Both engines agree on hand-checked elections and on 150 random elections; a one-vote difference blocks publication and alerts.

`.github/workflows/s4175334-ballot-integrity.yml` runs all of these plus `npm audit` on every push and pull request.

## Demo script (for the presentation)

1. **Terminal:** mark off `V0001`, rank candidates, cast. Point out the signed receipt.
2. Try `V0001` again: refused (SR-13).
3. Tick **Simulate network outage**. Vote as `V0006`, `V0007`, and `V0003` (who already voted). The queue counter rises (SR-16).
4. Untick. Within seconds the queue empties; the receipt shows `V0003`'s offline ballot rejected as `DECLARATION_ALREADY_MARKED_OFF`.
5. **Officer console** (`/admin`, use `ADMIN_API_TOKEN`): tick **simulate a defect in Engine B**, run. Result is BLOCKED, the differing cell is highlighted, an alert appears (SR-15).
6. Untick, run again: MATCHED. Close the election, run, publish.

## Integration notes for the team

- **SR-02 (Hrishiraj):** ballot tokens are RS256 and verified with algorithms pinned to `['RS256']`, matching the SR-02 standard. Officer endpoints use a placeholder bearer token (`requireOfficer` in `routes.js`); swap in the SR-01/SR-02 middleware when merged.
- **SR-05 / SR-08 (Caressa):** ballot rows carry no voter, terminal, batch or timestamp columns. Separate pools per schema are ready for subnet segregation.
- **SR-09 / SR-10 (Mmhachio):** replace the body of `audit()` with the secure logger. CVRs carry a SHA-384 hash that both engines verify before counting.
- **SR-17 (Vishal):** run the terminal-to-server link over mTLS in deployment; batch signatures still protect integrity end to end.

## Known limitations (for the report)

- **No hardware TPM** in the prototype (SR-14). Also note that most TPM 2.0 chips in service support RSA and ECDSA P-256 rather than Ed25519, so a hardware rollout would likely sign with ECDSA P-256. The verification code works for either.
- An **offline declaration** is marked off on arrival. If the ballot transaction then fails, that voter is marked off without a stored ballot (same failure mode as a voter who leaves after receiving a token); officials would handle it as a declaration vote.
- Terminals must finish syncing before the election is closed; batches are refused after close.
- The terminal's local API trusts anyone on `127.0.0.1` (the kiosk itself).
