// SR-14: terminal signing key. Owner: Muzammil Malek (s4175334)
//
// TerminalSigner interface - any signer must provide:
//   algorithm        string, e.g. 'Ed25519'
//   publicKeyPem()   SPKI PEM registered with the Ballot Store at enrolment
//   sign(bytes)      base64 signature over the given bytes
//
// SoftwareEd25519Signer is the prototype implementation: the private key is
// generated on the terminal, written with owner-only permissions, and never
// sent anywhere. A production TpmSigner (via tpm2-tss) would implement the
// same three members, with the key created inside the TPM as non-exportable,
// so nothing else in the system would change.
//
// Note for the report: most TPM 2.0 chips in service today support RSA and
// ECDSA P-256 but not Ed25519, so a hardware rollout would likely sign with
// ECDSA P-256. The server already verifies via node:crypto, which handles both.

import fs from 'node:fs';
import path from 'node:path';
import { generateKeyPairSync, createPrivateKey, createPublicKey, sign as cryptoSign } from 'node:crypto';

export class SoftwareEd25519Signer {
  algorithm = 'Ed25519';
  #privateKey;
  #publicKeyPem;

  constructor(privateKey) {
    this.#privateKey = privateKey;
    this.#publicKeyPem = createPublicKey(privateKey).export({ type: 'spki', format: 'pem' });
  }

  static loadOrCreate(keyPath) {
    if (!fs.existsSync(keyPath)) {
      fs.mkdirSync(path.dirname(keyPath), { recursive: true, mode: 0o700 });
      const { privateKey } = generateKeyPairSync('ed25519');
      fs.writeFileSync(keyPath, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
    }
    return new SoftwareEd25519Signer(createPrivateKey(fs.readFileSync(keyPath)));
  }

  publicKeyPem() {
    return this.#publicKeyPem;
  }

  sign(bytes) {
    return cryptoSign(null, bytes, this.#privateKey).toString('base64');
  }
}
