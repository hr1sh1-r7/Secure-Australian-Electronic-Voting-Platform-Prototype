// Local API behind the polling terminal GUI. Listens on 127.0.0.1 only.
// Owner: Muzammil Malek (s4175334)
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import { OfflineError, HttpError } from './serverClient.js';
import { QueueClosedError } from './queue.js';

const here = path.dirname(fileURLToPath(import.meta.url));
const VOTER_ID = /^[A-Za-z0-9]{3,20}$/;

export function createTerminalApp({ cfg, queue, client, sync, getElection }) {
  const app = express();
  app.disable('x-powered-by');
  app.use(helmet({
    contentSecurityPolicy: {
      directives: { defaultSrc: ["'self'"], scriptSrc: ["'self'"], styleSrc: ["'self'"], connectSrc: ["'self'"], frameAncestors: ["'none'"] },
    },
  }));
  app.use(express.json({ limit: '32kb' }));

  // One-time ballot sessions. The authorization token stays in the terminal
  // process and is never sent to the browser.
  const sessions = new Map();
  const takeSession = (id) => {
    const s = sessions.get(id);
    sessions.delete(id);
    return s && s.expires > Date.now() ? s : null;
  };

  app.get('/api/status', (req, res) => {
    const election = getElection();
    res.json({
      terminal_id: cfg.terminalId,
      polling_place: cfg.pollingPlace,
      online: sync.online && !client.forcedOffline,
      network_disabled: client.forcedOffline,
      offline_since: queue.offlineSince(),
      accepting_ballots: queue.acceptingBallots(),
      ...queue.counts(),
      last_sync_at: sync.lastSyncAt,
      last_error: sync.lastError,
      last_receipt: sync.lastReceipt(),
      election: election ? { election_id: election.election_id, name: election.name, status: election.status } : null,
    });
  });

  app.get('/api/election', (req, res) => {
    const e = getElection();
    if (!e) return res.status(503).json({ error: 'NO_ELECTION_LOADED' });
    res.json(e);
  });

  // Step 1: the polling official identifies the voter.
  app.post('/api/voters/authorize', async (req, res) => {
    const voterId = req.body?.voter_id;
    if (typeof voterId !== 'string' || !VOTER_ID.test(voterId)) {
      return res.status(400).json({ error: 'INVALID_VOTER_ID' });
    }
    let auth;
    let mode;
    try {
      // Online: SR-13 mark-off at the central service, nationwide check.
      const { token } = await client.authorize(cfg.electionId, voterId);
      auth = { type: 'token', token };
      mode = 'online';
    } catch (err) {
      if (err instanceof HttpError) {
        return res.status(err.status).json({ error: err.message });
      }
      if (!(err instanceof OfflineError)) throw err;
      // Offline: SR-16 declaration vote, reconciled on reconnection.
      queue.markOffline();
      sync.online = false;
      if (!queue.acceptingBallots()) return res.status(423).json({ error: 'OFFLINE_LIMIT_REACHED' });
      auth = { type: 'declaration', voter_id: voterId };
      mode = 'declaration';
    }
    const sessionId = randomUUID();
    sessions.set(sessionId, { auth, expires: Date.now() + cfg.sessionTtlMs });
    res.json({ session_id: sessionId, mode });
  });

  // Step 2: the voter submits their ranked ballot.
  app.post('/api/ballots', (req, res) => {
    const { session_id: sessionId, preferences } = req.body ?? {};
    const election = getElection();
    const session = typeof sessionId === 'string' ? takeSession(sessionId) : null;
    if (!session) return res.status(401).json({ error: 'SESSION_INVALID_OR_EXPIRED' });

    const known = new Set(election.candidates);
    const formal = Array.isArray(preferences) && preferences.length > 0 && preferences.length <= known.size &&
      new Set(preferences).size === preferences.length && preferences.every((p) => known.has(p));
    if (!formal) return res.status(400).json({ error: 'INFORMAL_BALLOT' });

    try {
      const { ballot_id: ballotId } = queue.enqueue({ ballot_id: randomUUID(), preferences, auth: session.auth });
      sync.flush(); // send now if we can; the queue keeps it safe if not
      res.status(201).json({ queued: true, ballot_id: ballotId });
    } catch (err) {
      if (err instanceof QueueClosedError) return res.status(423).json({ error: err.code });
      throw err;
    }
  });

  // Demo control: simulate the polling place losing its network link.
  app.post('/api/demo/network', async (req, res) => {
    client.forcedOffline = req.body?.offline === true;
    if (client.forcedOffline) {
      sync.online = false;
      queue.markOffline();
    }
    await sync.flush();
    res.json({ network_disabled: client.forcedOffline, online: sync.online });
  });

  app.post('/api/sync/flush', async (req, res) => {
    await sync.flush();
    res.json({ online: sync.online, ...queue.counts(), last_error: sync.lastError });
  });

  app.use(express.static(path.resolve(here, '..', 'public')));
  app.use((req, res) => res.status(404).json({ error: 'NOT_FOUND' }));
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    console.error('[terminal error]', err);
    res.status(500).json({ error: 'INTERNAL_ERROR' });
  });
  return app;
}
