// Talks to the central server. Distinguishes "network unreachable" (go
// offline, keep queueing) from "server said no" (show the error).
import { canonicalize } from '../../shared/canonical.js';

export class OfflineError extends Error {}
export class HttpError extends Error {
  constructor(status, body) {
    super(body?.error ?? `HTTP ${status}`);
    this.status = status;
    this.body = body;
  }
}

export class ServerClient {
  constructor({ baseUrl, terminalId, signer, timeoutMs = 8000 }) {
    this.baseUrl = baseUrl;
    this.terminalId = terminalId;
    this.signer = signer;
    this.timeoutMs = timeoutMs;
    this.forcedOffline = false; // demo switch: behave as if the network is down
  }

  async #request(method, route, body, headers = {}) {
    if (this.forcedOffline) throw new OfflineError('Network disabled (demo)');
    let res;
    try {
      res = await fetch(this.baseUrl + route, {
        method,
        headers: { 'content-type': 'application/json', ...headers },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: AbortSignal.timeout(this.timeoutMs),
      });
    } catch (err) {
      throw new OfflineError(err.message);
    }
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new HttpError(res.status, data);
    return { status: res.status, data };
  }

  health() {
    return this.#request('GET', '/api/health');
  }

  async election(electionId) {
    return (await this.#request('GET', `/api/elections/${encodeURIComponent(electionId)}`)).data;
  }

  async receiptKey() {
    return (await this.#request('GET', '/api/keys/receipt')).data;
  }

  register({ pollingPlace, enrolmentSecret }) {
    return this.#request(
      'POST',
      '/api/terminals/register',
      { terminal_id: this.terminalId, public_key_pem: this.signer.publicKeyPem(), polling_place: pollingPlace },
      { 'x-enrolment-secret': enrolmentSecret },
    );
  }

  // SR-13: signed request to mark a voter off and get a ballot token.
  async authorize(electionId, voterId) {
    const fields = { terminal_id: this.terminalId, election_id: electionId, voter_id: voterId, timestamp: new Date().toISOString() };
    const signature = this.signer.sign(Buffer.from(canonicalize(fields)));
    return (await this.#request('POST', '/api/markoff/authorize', { ...fields, signature })).data;
  }

  async sendBatch(batch) {
    return (await this.#request('POST', '/api/ballot-store/batches', batch)).data;
  }
}
