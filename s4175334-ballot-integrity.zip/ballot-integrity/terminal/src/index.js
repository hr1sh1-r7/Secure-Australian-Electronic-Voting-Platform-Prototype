import fs from 'node:fs';
import path from 'node:path';
import { config, queueKey } from './config.js';
import { SoftwareEd25519Signer } from './signer.js';
import { OfflineQueue } from './queue.js';
import { ServerClient, OfflineError } from './serverClient.js';
import { SyncAgent } from './sync.js';
import { createTerminalApp } from './app.js';

fs.mkdirSync(config.dataDir, { recursive: true, mode: 0o700 });

const signer = SoftwareEd25519Signer.loadOrCreate(path.join(config.dataDir, 'terminal-signing-key.pem'));
const queue = new OfflineQueue({
  dbPath: path.join(config.dataDir, `queue-${config.terminalId}.sqlite`),
  key: queueKey(),
  terminalId: config.terminalId,
  electionId: config.electionId,
  maxOfflineMs: config.maxOfflineMs,
});
const client = new ServerClient({ baseUrl: config.serverUrl, terminalId: config.terminalId, signer });

// Enrol once: register our public key and pin the Ballot Store receipt key.
if (!queue.getState('enrolled')) {
  if (!config.enrolmentSecret) throw new Error('ENROLMENT_SECRET is required for first-time enrolment');
  await client.register({ pollingPlace: config.pollingPlace, enrolmentSecret: config.enrolmentSecret });
  const rk = await client.receiptKey();
  queue.setState('receipt_key_pem', rk.public_key_pem);
  queue.setState('enrolled', new Date().toISOString());
  console.log(`Enrolled ${config.terminalId} and pinned receipt key ${rk.kid}`);
}

// Load the ballot paper; fall back to the cached copy if offline at startup.
let election = queue.getState('election') ? JSON.parse(queue.getState('election')) : null;
try {
  election = await client.election(config.electionId);
  queue.setState('election', JSON.stringify(election));
} catch (err) {
  if (!(err instanceof OfflineError) || !election) throw err;
  console.warn('Server unreachable: using cached ballot paper');
}

const sync = new SyncAgent({
  queue, client, signer,
  terminalId: config.terminalId,
  electionId: config.electionId,
  intervalMs: config.syncIntervalMs,
  maxBackoffMs: config.maxBackoffMs,
  maxBatchEntries: config.maxBatchEntries,
});
sync.start();

createTerminalApp({ cfg: config, queue, client, sync, getElection: () => election })
  .listen(config.port, '127.0.0.1', () => {
    console.log(`Polling terminal ${config.terminalId} on http://127.0.0.1:${config.port}`);
  });
