// SR-14 + SR-16: builds signed batches from the queue and forwards them.
// Owner: Muzammil Malek (s4175334)
//
//  - Checks every 30 s while online. While offline it retries with backoff
//    (30 s -> 60 s -> 120 s cap), so a queue is sent at most ~2 minutes after
//    the network returns: well inside the 15-minute requirement.
//  - The batch being sent is saved (encrypted) before sending. If the
//    connection drops before the receipt arrives, the identical batch is
//    resent and the server returns the original receipt. Nothing is counted
//    twice and the hash chain stays intact.
//  - Each receipt's Ed25519 signature is checked against the Ballot Store key
//    pinned at enrolment, and must match the batch's ID and hash.

import { randomUUID, createPublicKey, verify as cryptoVerify } from 'node:crypto';
import { canonicalize, sha256Hex, batchSigningBytes } from '../../shared/canonical.js';
import { OfflineError, HttpError } from './serverClient.js';

export function verifyReceipt(receipt, batch, receiptKeyPem) {
  if (!receipt || typeof receipt.signature !== 'string') return false;
  const { signature, ...body } = receipt;
  let ok = false;
  try {
    ok = cryptoVerify(null, Buffer.from(canonicalize(body)), createPublicKey(receiptKeyPem), Buffer.from(signature, 'base64'));
  } catch {
    ok = false;
  }
  return ok && receipt.batch_id === batch.batch_id && receipt.batch_hash === sha256Hex(batchSigningBytes(batch));
}

export class SyncAgent {
  constructor({ queue, client, signer, terminalId, electionId, intervalMs, maxBackoffMs, maxBatchEntries, log = console }) {
    Object.assign(this, { queue, client, signer, terminalId, electionId, intervalMs, maxBackoffMs, maxBatchEntries, log });
    this.online = false;
    this.lastError = null;
    this.lastSyncAt = null;
    this.backoffMs = intervalMs;
    this.flushing = null;
    this.timer = null;
  }

  start() {
    this.#schedule(0);
  }

  stop() {
    clearTimeout(this.timer);
    this.timer = null;
  }

  #schedule(ms) {
    clearTimeout(this.timer);
    this.timer = setTimeout(async () => {
      await this.flush();
      this.#schedule(this.online ? this.intervalMs : this.backoffMs);
    }, ms);
    this.timer.unref?.();
  }

  buildBatch(entries) {
    const batch = {
      batch_id: randomUUID(),
      terminal_id: this.terminalId,
      election_id: this.electionId,
      created_at: new Date().toISOString(),
      chain_start: entries[0].prev_hash,
      entries,
    };
    batch.signature = this.signer.sign(batchSigningBytes(batch));
    return batch;
  }

  // Send everything queued. Concurrent callers share one flush.
  flush() {
    if (!this.flushing) {
      this.flushing = this.#flush().finally(() => {
        this.flushing = null;
      });
    }
    return this.flushing;
  }

  async #flush() {
    try {
      for (;;) {
        let batch = this.queue.getSecretState('inflight_batch');
        if (!batch) {
          const entries = this.queue.pending(this.maxBatchEntries);
          if (entries.length === 0) {
            await this.client.health();
            this.#wentOnline();
            return;
          }
          batch = this.buildBatch(entries);
          this.queue.setSecretState('inflight_batch', batch);
        }

        let response;
        try {
          response = await this.client.sendBatch(batch);
        } catch (err) {
          if (err instanceof HttpError) {
            // The server refused the batch outright, so it changed nothing.
            // Keep the ballots queued and build a fresh batch next time.
            this.queue.setSecretState('inflight_batch', null);
            this.lastError = `Batch refused: ${err.message}`;
            this.log.error?.(`[sync] ${this.lastError}`);
            this.online = true;
            return;
          }
          throw err;
        }

        const pinned = this.queue.getState('receipt_key_pem');
        if (!verifyReceipt(response.receipt, batch, pinned)) {
          this.lastError = 'Receipt signature invalid: batch kept for resend';
          this.log.error?.(`[sync] ${this.lastError}`);
          return;
        }
        this.queue.markSent(batch.entries.map((e) => e.ballot_id), batch.batch_id);
        this.queue.setSecretState('inflight_batch', null);
        this.queue.setState('last_receipt', JSON.stringify(response.receipt));
        this.lastError = null;
        this.#wentOnline();
      }
    } catch (err) {
      if (err instanceof OfflineError) {
        if (this.online || !this.queue.offlineSince()) this.log.warn?.('[sync] network unreachable: queueing offline');
        this.online = false;
        this.queue.markOffline();
        this.backoffMs = Math.min(this.backoffMs * 2, this.maxBackoffMs);
        return;
      }
      this.lastError = err.message;
      this.log.error?.('[sync]', err);
    }
  }

  #wentOnline() {
    this.online = true;
    this.lastSyncAt = new Date().toISOString();
    this.backoffMs = this.intervalMs;
    this.queue.markOnline();
  }

  lastReceipt() {
    const raw = this.queue.getState('last_receipt');
    return raw ? JSON.parse(raw) : null;
  }
}
