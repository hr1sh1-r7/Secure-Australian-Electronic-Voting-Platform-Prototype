// SR-16: Offline Store-and-Forward Voting Continuity - terminal queue
// Owner: Muzammil Malek (s4175334)
//
// Selected solution (Part 2): AES-256-GCM encrypted local SQLite queue.
//
//  - Every ballot is written to the queue first, online or offline, so there
//    is one code path and nothing is lost if the network drops mid-send.
//  - Each entry is encrypted with AES-256-GCM (random 96-bit IV). The
//    terminal ID, ballot ID and entry hash are bound in as associated data,
//    so ciphertexts cannot be swapped between rows without detection.
//  - Entries are hash-chained (prev_hash -> entry_hash). The Ballot Store
//    checks the chain, so deleting or reordering queued ballots is detected.
//  - After 12 hours offline the queue refuses new ballots.

import { DatabaseSync } from 'node:sqlite';
import { randomBytes, createCipheriv, createDecipheriv } from 'node:crypto';
import { canonicalize, genesisHash, computeEntryHash } from '../../shared/canonical.js';

export class QueueClosedError extends Error {
  constructor() {
    super('OFFLINE_LIMIT_REACHED');
    this.code = 'OFFLINE_LIMIT_REACHED';
  }
}

export class QueueTamperError extends Error {}

export class OfflineQueue {
  #db;
  #key;

  constructor({ dbPath, key, terminalId, electionId, maxOfflineMs, now = () => Date.now() }) {
    if (!Buffer.isBuffer(key) || key.length !== 32) throw new Error('AES-256 key must be 32 bytes');
    this.#key = key;
    this.terminalId = terminalId;
    this.electionId = electionId;
    this.maxOfflineMs = maxOfflineMs;
    this.now = now;
    this.#db = new DatabaseSync(dbPath);
    this.#db.exec(`
      PRAGMA journal_mode = WAL;
      CREATE TABLE IF NOT EXISTS entries (
        seq         INTEGER PRIMARY KEY AUTOINCREMENT,
        ballot_id   TEXT UNIQUE NOT NULL,
        prev_hash   TEXT NOT NULL,
        entry_hash  TEXT NOT NULL,
        iv          BLOB NOT NULL,
        tag         BLOB NOT NULL,
        ciphertext  BLOB NOT NULL,
        sent_batch  TEXT
      );
      CREATE TABLE IF NOT EXISTS state (k TEXT PRIMARY KEY, v TEXT NOT NULL);
    `);
  }

  // ------------------------------------------------------------- crypto --

  #encrypt(plaintext, aad) {
    const iv = randomBytes(12);
    const cipher = createCipheriv('aes-256-gcm', this.#key, iv);
    cipher.setAAD(Buffer.from(aad));
    const ciphertext = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
    return { iv, tag: cipher.getAuthTag(), ciphertext };
  }

  #decrypt({ iv, tag, ciphertext }, aad) {
    const decipher = createDecipheriv('aes-256-gcm', this.#key, iv);
    decipher.setAAD(Buffer.from(aad));
    decipher.setAuthTag(tag);
    try {
      return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8');
    } catch {
      throw new QueueTamperError('Queue entry failed authentication (tampered or wrong key)');
    }
  }

  #aad(ballotId, entryHash) {
    return `${this.terminalId}|${ballotId}|${entryHash}`;
  }

  // -------------------------------------------------------------- state --

  getState(k) {
    return this.#db.prepare('SELECT v FROM state WHERE k = ?').get(k)?.v ?? null;
  }

  setState(k, v) {
    if (v === null || v === undefined) this.#db.prepare('DELETE FROM state WHERE k = ?').run(k);
    else this.#db.prepare('INSERT INTO state (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v').run(k, String(v));
  }

  // Sensitive state (the in-flight batch holds ballots) is encrypted too.
  setSecretState(k, obj) {
    if (obj === null) return this.setState(k, null);
    const box = this.#encrypt(JSON.stringify(obj), `${this.terminalId}|state|${k}`);
    this.setState(k, JSON.stringify({ iv: box.iv.toString('base64'), tag: box.tag.toString('base64'), ct: box.ciphertext.toString('base64') }));
  }

  getSecretState(k) {
    const raw = this.getState(k);
    if (!raw) return null;
    const b = JSON.parse(raw);
    return JSON.parse(this.#decrypt({ iv: Buffer.from(b.iv, 'base64'), tag: Buffer.from(b.tag, 'base64'), ciphertext: Buffer.from(b.ct, 'base64') }, `${this.terminalId}|state|${k}`));
  }

  chainHead() {
    return this.getState('chain_head') ?? genesisHash(this.terminalId);
  }

  // ----------------------------------------------------- offline window --

  markOffline() {
    if (!this.getState('offline_since')) this.setState('offline_since', this.now());
  }

  markOnline() {
    this.setState('offline_since', null);
  }

  offlineSince() {
    const v = this.getState('offline_since');
    return v ? Number(v) : null;
  }

  acceptingBallots() {
    const since = this.offlineSince();
    return since === null || this.now() - since <= this.maxOfflineMs;
  }

  // --------------------------------------------------------------- queue --

  enqueue({ ballot_id, preferences, auth }) {
    if (!this.acceptingBallots()) throw new QueueClosedError();
    const entry = {
      ballot_id,
      election_id: this.electionId,
      preferences,
      auth,
      queued_at: new Date(this.now()).toISOString(),
      prev_hash: this.chainHead(),
    };
    entry.entry_hash = computeEntryHash(entry);
    const box = this.#encrypt(canonicalize(entry), this.#aad(ballot_id, entry.entry_hash));

    this.#db.exec('BEGIN IMMEDIATE');
    try {
      this.#db
        .prepare('INSERT INTO entries (ballot_id, prev_hash, entry_hash, iv, tag, ciphertext) VALUES (?, ?, ?, ?, ?, ?)')
        .run(ballot_id, entry.prev_hash, entry.entry_hash, box.iv, box.tag, box.ciphertext);
      this.setState('chain_head', entry.entry_hash);
      this.#db.exec('COMMIT');
    } catch (err) {
      this.#db.exec('ROLLBACK');
      throw err;
    }
    return { ballot_id, entry_hash: entry.entry_hash };
  }

  pending(limit) {
    const rows = this.#db
      .prepare('SELECT * FROM entries WHERE sent_batch IS NULL ORDER BY seq LIMIT ?')
      .all(limit);
    return rows.map((row) => {
      const entry = JSON.parse(this.#decrypt(row, this.#aad(row.ballot_id, row.entry_hash)));
      if (computeEntryHash(entry) !== row.entry_hash || entry.prev_hash !== row.prev_hash) {
        throw new QueueTamperError(`Queue entry ${row.ballot_id} does not match its hash`);
      }
      return entry;
    });
  }

  markSent(ballotIds, batchId) {
    const stmt = this.#db.prepare('UPDATE entries SET sent_batch = ? WHERE ballot_id = ?');
    this.#db.exec('BEGIN');
    for (const id of ballotIds) stmt.run(batchId, id);
    this.#db.exec('COMMIT');
  }

  counts() {
    const r = this.#db
      .prepare('SELECT SUM(sent_batch IS NULL) AS queued, SUM(sent_batch IS NOT NULL) AS sent FROM entries')
      .get();
    return { queued: r.queued ?? 0, sent: r.sent ?? 0 };
  }

  // For tests/inspection: raw rows as stored on disk.
  rawRows() {
    return this.#db.prepare('SELECT * FROM entries ORDER BY seq').all();
  }

  rawDb() {
    return this.#db;
  }

  close() {
    this.#db.close();
  }
}
