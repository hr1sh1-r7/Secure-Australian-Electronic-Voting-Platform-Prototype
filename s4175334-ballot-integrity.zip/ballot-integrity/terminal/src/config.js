import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const env = process.env;

export const config = {
  port: Number(env.TERMINAL_PORT ?? 4100),
  serverUrl: (env.SERVER_URL ?? 'http://localhost:3000').replace(/\/$/, ''),
  terminalId: env.TERMINAL_ID ?? 'T-MELB-001',
  pollingPlace: env.POLLING_PLACE ?? 'Melbourne Town Hall',
  electionId: env.ELECTION_ID ?? 'VIC-MELB-2026',
  dataDir: env.TERMINAL_DATA_DIR ?? path.resolve(here, '..', 'data'),
  enrolmentSecret: env.ENROLMENT_SECRET ?? '',
  // 32-byte AES-256 key, base64. In production this would be sealed in the TPM.
  queueKeyB64: env.TERMINAL_QUEUE_KEY ?? '',
  syncIntervalMs: Number(env.SYNC_INTERVAL_MS ?? 30_000),
  maxBackoffMs: 120_000,
  maxOfflineMs: 12 * 60 * 60 * 1000, // SR-16: 12 hours
  maxBatchEntries: 200,
  sessionTtlMs: 10 * 60 * 1000,
};

export function queueKey() {
  const key = Buffer.from(config.queueKeyB64, 'base64');
  if (key.length !== 32) {
    throw new Error('TERMINAL_QUEUE_KEY must be a base64-encoded 32-byte key. Generate one with:\n' +
      "  node -e \"console.log(require('crypto').randomBytes(32).toString('base64'))\"");
  }
  return key;
}
