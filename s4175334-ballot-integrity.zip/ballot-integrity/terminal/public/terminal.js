// Polling terminal GUI. All data is rendered with textContent (no innerHTML).
'use strict';

const $ = (id) => document.getElementById(id);
let session = null;
let election = null;
let ranking = [];

async function call(method, path, body) {
  const res = await fetch(path, {
    method,
    headers: { 'content-type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  return { ok: res.ok, status: res.status, body: await res.json().catch(() => ({})) };
}

function show(step) {
  for (const id of ['officialStep', 'ballotStep', 'doneStep']) $(id).hidden = id !== step;
}

const MESSAGES = {
  ALREADY_MARKED_OFF: 'This voter has already been marked off. Do not issue a ballot.',
  CONCURRENT_REQUEST: 'This voter is being marked off at another terminal right now. Do not issue a ballot.',
  NOT_ON_ROLL: 'Voter ID not found on the electoral roll.',
  INVALID_VOTER_ID: 'Voter ID should be 3 to 20 letters or digits.',
  OFFLINE_LIMIT_REACHED: 'Offline for more than 12 hours: this terminal has stopped accepting ballots.',
};

async function refreshStatus() {
  const { body: s } = await call('GET', '/api/status');
  $('terminalId').textContent = s.terminal_id;
  $('pollingPlace').textContent = s.polling_place;
  $('queued').textContent = s.queued;
  $('sent').textContent = s.sent;
  $('netToggle').checked = s.network_disabled;
  const pill = $('netPill');
  pill.textContent = s.online ? 'ONLINE' : 'OFFLINE';
  pill.className = 'pill ' + (s.online ? 'on' : 'off');

  const banner = $('offlineBanner');
  if (!s.online && s.offline_since) {
    const mins = Math.floor((Date.now() - s.offline_since) / 60_000);
    const dur = mins < 60 ? `${mins} min` : `${(mins / 60).toFixed(1)} h`;
    banner.textContent = s.accepting_ballots
      ? `Offline for ${dur} (limit 12 h). Ballots are encrypted and queued, and will be sent automatically when the network returns.`
      : MESSAGES.OFFLINE_LIMIT_REACHED;
    banner.hidden = false;
  } else if (s.last_error) {
    banner.textContent = s.last_error;
    banner.hidden = false;
  } else {
    banner.hidden = true;
  }

  const r = s.last_receipt;
  const dl = $('receipt');
  dl.replaceChildren();
  if (!r) {
    dl.append(Object.assign(document.createElement('dt'), { textContent: 'None yet' }));
  } else {
    const rows = [
      ['Batch', r.batch_id],
      ['Received', new Date(r.received_at).toLocaleString()],
      ['Ballots', `${r.ballot_count} (${r.accepted.length} accepted, ${r.rejected.length} rejected)`],
      ['Rejected', r.rejected.map((x) => x.reason).join(', ') || 'none'],
      ['Batch hash', r.batch_hash],
      ['Signed by', `${r.signer} (signature verified)`],
    ];
    for (const [k, v] of rows) {
      dl.append(Object.assign(document.createElement('dt'), { textContent: k }));
      dl.append(Object.assign(document.createElement('dd'), { textContent: v }));
    }
  }
}

function renderBallot() {
  const list = $('candidates');
  list.replaceChildren();
  for (const c of election.candidates) {
    const li = document.createElement('li');
    const btn = document.createElement('button');
    btn.type = 'button';
    const rank = ranking.indexOf(c);
    if (rank >= 0) btn.classList.add('ranked');
    const box = document.createElement('span');
    box.className = 'box';
    box.textContent = rank >= 0 ? String(rank + 1) : '';
    const name = document.createElement('span');
    name.textContent = c;
    btn.append(box, name);
    btn.setAttribute('aria-label', rank >= 0 ? `${c}, preference ${rank + 1}` : `${c}, not numbered`);
    btn.addEventListener('click', () => {
      if (!ranking.includes(c)) ranking.push(c);
      renderBallot();
    });
    li.append(btn);
    list.append(li);
  }
  $('castBtn').disabled = ranking.length === 0;
}

$('voterForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  $('voterMsg').textContent = '';
  const res = await call('POST', '/api/voters/authorize', { voter_id: $('voterId').value.trim() });
  if (!res.ok) {
    $('voterMsg').textContent = MESSAGES[res.body.error] ?? `Refused: ${res.body.error}`;
    refreshStatus();
    return;
  }
  session = res.body.session_id;
  $('voterId').value = '';
  ranking = [];
  $('modeNote').hidden = res.body.mode !== 'declaration';
  $('modeNote').textContent = 'Offline declaration vote: the voter will be checked against the national roll when this terminal reconnects.';
  renderBallot();
  show('ballotStep');
  refreshStatus();
});

$('clearBtn').addEventListener('click', () => {
  ranking = [];
  renderBallot();
});

$('castBtn').addEventListener('click', async () => {
  $('castBtn').disabled = true;
  const res = await call('POST', '/api/ballots', { session_id: session, preferences: ranking });
  session = null;
  if (!res.ok) {
    show('officialStep');
    $('voterMsg').textContent = MESSAGES[res.body.error] ?? `Ballot not recorded: ${res.body.error}`;
    return;
  }
  $('doneMsg').textContent = 'Thank you. Your ballot has been stored encrypted on this terminal and will be signed and forwarded to the Ballot Store.';
  show('doneStep');
  setTimeout(refreshStatus, 600);
});

$('nextBtn').addEventListener('click', () => show('officialStep'));

$('netToggle').addEventListener('change', async (e) => {
  await call('POST', '/api/demo/network', { offline: e.target.checked });
  refreshStatus();
});

(async () => {
  const res = await call('GET', '/api/election');
  election = res.body;
  $('electionName').textContent = election.name;
  await refreshStatus();
  setInterval(refreshStatus, 3000);
})();
