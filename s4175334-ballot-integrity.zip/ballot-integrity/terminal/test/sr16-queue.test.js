// SR-16 unit tests: encrypted, hash-chained, time-limited offline queue
// SR-14 unit tests: terminal-side receipt verification
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomBytes, randomUUID, generateKeyPairSync, sign as cryptoSign } from 'node:crypto';
import { OfflineQueue, QueueClosedError, QueueTamperError } from '../src/queue.js';
import { SyncAgent, verifyReceipt } from '../src/sync.js';
import { SoftwareEd25519Signer } from '../src/signer.js';
import { OfflineError } from '../src/serverClient.js';
import { canonicalize, sha256Hex, genesisHash, computeEntryHash, batchSigningBytes } from '../../shared/canonical.js';

const HOUR = 3_600_000;

function makeQueue(overrides = {}) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bi-q-'));
  return new OfflineQueue({
    dbPath: path.join(dir, 'q.sqlite'),
    key: randomBytes(32),
    terminalId: 'T-TEST',
    electionId: 'VIC-MELB-2026',
    maxOfflineMs: 12 * HOUR,
    ...overrides,
  });
}
const ballot = (voter = 'V0001', prefs = ['CHEN', 'ALVAREZ']) => ({
  ballot_id: randomUUID(), preferences: prefs, auth: { type: 'declaration', voter_id: voter },
});

test('queued ballots are not readable on disk (AES-256-GCM)', () => {
  const q = makeQueue();
  q.enqueue(ballot('V0777', ['DIAZ', 'BROWN']));
  const raw = Buffer.concat(q.rawRows().map((r) => Buffer.from(r.ciphertext))).toString('latin1');
  assert.ok(!raw.includes('DIAZ'));
  assert.ok(!raw.includes('V0777'));
  assert.deepEqual(q.pending(10)[0].preferences, ['DIAZ', 'BROWN']);
});

test('a modified ciphertext is detected', () => {
  const q = makeQueue();
  q.enqueue(ballot());
  q.rawDb().prepare("UPDATE entries SET ciphertext = randomblob(length(ciphertext))").run();
  assert.throws(() => q.pending(10), QueueTamperError);
});

test('swapping ciphertexts between two rows is detected (associated data binding)', () => {
  const q = makeQueue();
  q.enqueue(ballot('V0001', ['ALVAREZ']));
  q.enqueue(ballot('V0002', ['BROWN']));
  const [a, b] = q.rawRows();
  const upd = q.rawDb().prepare('UPDATE entries SET iv = ?, tag = ?, ciphertext = ? WHERE seq = ?');
  upd.run(b.iv, b.tag, b.ciphertext, a.seq);
  upd.run(a.iv, a.tag, a.ciphertext, b.seq);
  assert.throws(() => q.pending(10), QueueTamperError);
});

test('a wrong key cannot read the queue', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bi-q-'));
  const opts = { dbPath: path.join(dir, 'q.sqlite'), terminalId: 'T-TEST', electionId: 'E-1', maxOfflineMs: HOUR };
  const q1 = new OfflineQueue({ ...opts, key: randomBytes(32) });
  q1.enqueue(ballot());
  q1.close();
  const q2 = new OfflineQueue({ ...opts, key: randomBytes(32) });
  assert.throws(() => q2.pending(10), QueueTamperError);
});

test('entries form an unbroken hash chain from the terminal genesis', () => {
  const q = makeQueue();
  for (let i = 0; i < 5; i++) q.enqueue(ballot(`V000${i}`));
  const entries = q.pending(10);
  let prev = genesisHash('T-TEST');
  for (const e of entries) {
    assert.equal(e.prev_hash, prev);
    assert.equal(computeEntryHash(e), e.entry_hash);
    prev = e.entry_hash;
  }
  assert.equal(q.chainHead(), prev);
});

test('ballots are accepted for 12 hours offline, then refused', () => {
  let now = Date.parse('2026-11-07T08:00:00Z');
  const q = makeQueue({ now: () => now });
  q.markOffline();
  now += 11.9 * HOUR;
  assert.doesNotThrow(() => q.enqueue(ballot()));
  now += 0.2 * HOUR;
  assert.throws(() => q.enqueue(ballot()), QueueClosedError);
  q.markOnline();
  assert.doesNotThrow(() => q.enqueue(ballot()));
});

// --- Sync agent with a fake server --------------------------------------

function fakeServer({ failFirstAfterCommit = false } = {}) {
  const { privateKey, publicKey } = generateKeyPairSync('ed25519');
  const store = { batches: new Map(), ballots: new Set(), down: false, calls: 0 };
  const signReceipt = (body) => {
    const b = { ...body, signer: 'test' };
    return { ...b, signature: cryptoSign(null, Buffer.from(canonicalize(b)), privateKey).toString('base64') };
  };
  const client = {
    async health() {
      if (store.down) throw new OfflineError('down');
    },
    async sendBatch(batch) {
      store.calls++;
      if (store.down) throw new OfflineError('down');
      const prev = store.batches.get(batch.batch_id);
      if (prev) return { receipt: prev, duplicate: true };
      for (const e of batch.entries) store.ballots.add(e.ballot_id);
      const receipt = signReceipt({
        batch_id: batch.batch_id, batch_hash: sha256Hex(batchSigningBytes(batch)),
        ballot_count: batch.entries.length, accepted: batch.entries.map((e) => e.ballot_id), rejected: [],
        received_at: new Date().toISOString(),
      });
      store.batches.set(batch.batch_id, receipt);
      if (failFirstAfterCommit && store.calls === 1) throw new OfflineError('connection reset after commit');
      return { receipt, duplicate: false };
    },
  };
  return { client, store, receiptKeyPem: publicKey.export({ type: 'spki', format: 'pem' }), privateKey };
}

function makeAgent(q, client) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bi-k-'));
  const signer = SoftwareEd25519Signer.loadOrCreate(path.join(dir, 'k.pem'));
  return new SyncAgent({
    queue: q, client, signer, terminalId: 'T-TEST', electionId: 'VIC-MELB-2026',
    intervalMs: 30_000, maxBackoffMs: 120_000, maxBatchEntries: 2, log: {},
  });
}

test('queue is forwarded automatically once the network returns', async () => {
  const q = makeQueue();
  const srv = fakeServer();
  q.setState('receipt_key_pem', srv.receiptKeyPem);
  const agent = makeAgent(q, srv.client);
  srv.store.down = true;
  for (let i = 0; i < 5; i++) q.enqueue(ballot(`V00${i}`));
  await agent.flush();
  assert.equal(agent.online, false);
  assert.ok(q.offlineSince());
  assert.equal(q.counts().queued, 5);

  srv.store.down = false;
  await agent.flush();
  assert.equal(agent.online, true);
  assert.equal(q.counts().queued, 0);
  assert.equal(q.offlineSince(), null);
  assert.equal(srv.store.ballots.size, 5);
});

test('offline retry backoff never exceeds 2 minutes (well inside 15)', async () => {
  const q = makeQueue();
  const srv = fakeServer();
  q.setState('receipt_key_pem', srv.receiptKeyPem);
  const agent = makeAgent(q, srv.client);
  srv.store.down = true;
  for (let i = 0; i < 6; i++) await agent.flush();
  assert.equal(agent.backoffMs, 120_000);
});

test('lost receipt: the identical batch is resent and nothing is counted twice', async () => {
  const q = makeQueue();
  const srv = fakeServer({ failFirstAfterCommit: true });
  q.setState('receipt_key_pem', srv.receiptKeyPem);
  const agent = makeAgent(q, srv.client);
  q.enqueue(ballot('V0001'));
  await agent.flush(); // server stored it, but the response was lost
  assert.equal(q.counts().queued, 1);
  await agent.flush();
  assert.equal(q.counts().queued, 0);
  assert.equal(srv.store.batches.size, 1);
  assert.equal(srv.store.ballots.size, 1);
});

test('a receipt signed by the wrong key is rejected and the batch is kept', async () => {
  const q = makeQueue();
  const srv = fakeServer();
  q.setState('receipt_key_pem', generateKeyPairSync('ed25519').publicKey.export({ type: 'spki', format: 'pem' }));
  const agent = makeAgent(q, srv.client);
  q.enqueue(ballot());
  await agent.flush();
  assert.equal(q.counts().queued, 1);
  assert.match(agent.lastError, /Receipt signature invalid/);
});

test('verifyReceipt rejects a receipt for a different batch', () => {
  const srv = fakeServer();
  const body = { batch_id: randomUUID(), batch_hash: 'x', signer: 'test' };
  const receipt = { ...body, signature: cryptoSign(null, Buffer.from(canonicalize(body)), srv.privateKey).toString('base64') };
  assert.equal(verifyReceipt(receipt, { batch_id: randomUUID(), entries: [] }, srv.receiptKeyPem), false);
});

test('signer key file is owner-only and the signature verifies', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'bi-s-'));
  const keyPath = path.join(dir, 'k.pem');
  const signer = SoftwareEd25519Signer.loadOrCreate(keyPath);
  if (process.platform !== 'win32') assert.equal(fs.statSync(keyPath).mode & 0o077, 0);
  assert.ok(signer.sign(Buffer.from('hello')).length > 40);
});
