// Shared by the server and the polling terminal (SR-14, SR-16).
// Owner: Muzammil Malek (s4175334)
//
// Signatures and hash chains are computed over *canonical* JSON so that the
// same logical object always produces the same bytes, whatever key order or
// whitespace the sender used.

import { createHash } from 'node:crypto';

export function canonicalize(value) {
  if (value === null || typeof value !== 'object') {
    if (typeof value === 'number' && !Number.isFinite(value)) {
      throw new TypeError('Non-finite numbers cannot be canonicalised');
    }
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) {
    return '[' + value.map(canonicalize).join(',') + ']';
  }
  return (
    '{' +
    Object.keys(value)
      .filter((k) => value[k] !== undefined)
      .sort()
      .map((k) => JSON.stringify(k) + ':' + canonicalize(value[k]))
      .join(',') +
    '}'
  );
}

export function sha256Hex(data) {
  return createHash('sha256').update(data).digest('hex');
}

// First link of every terminal's queue chain (SR-16).
export function genesisHash(terminalId) {
  return sha256Hex('genesis:' + terminalId);
}

// An entry's hash covers every field of the entry, including prev_hash,
// so deleting, reordering or editing any queued ballot breaks the chain.
export function computeEntryHash(entry) {
  const { entry_hash: _ignored, ...body } = entry;
  return sha256Hex(canonicalize(body));
}

// Bytes that a batch signature covers: everything except the signature itself.
export function batchSigningBytes(batch) {
  const { signature: _ignored, ...body } = batch;
  return Buffer.from(canonicalize(body), 'utf8');
}
