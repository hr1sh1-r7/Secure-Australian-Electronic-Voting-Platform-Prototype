# Preferential Counting Rules Specification (SR-15)

**Owner:** Muzammil Malek (s4175334)

This is the **only** thing the two counting engines share. Engine A
(`server/src/tally/engineA.js`, JavaScript) and Engine B
(`tally-engine-b/engine_b.py`, Python) were written separately from this
document and share no counting code. If they ever disagree, at least one has
a defect (or has been tampered with), and publication is blocked.

## Input

```json
{
  "election_id": "VIC-MELB-2026",
  "candidates": ["ALVAREZ", "BROWN", "CHEN", "DIAZ"],
  "cvrs": [
    { "ballot_id": "<uuid>", "preferences": ["CHEN", "ALVAREZ"], "cvr_hash": "<sha384 hex>" }
  ]
}
```

## Rules

1. **Integrity check.** For every CVR, recompute
   `SHA-384( ballot_id + "|" + election_id + "|" + preferences joined by "," )`
   as lowercase hex. If any hash differs, stop and return
   `{"error": "INTEGRITY_FAILURE", "ballot_ids": [...sorted]}`. Nothing is counted.
2. **Formality.** A ballot is informal if it has no preferences, names a
   candidate not in `candidates`, or names a candidate twice. Informal ballots
   are counted in `informal` and take no further part.
3. **Rounds.** All candidates start as *continuing*. In each round, every
   formal ballot counts for its highest-ranked continuing candidate. A ballot
   with no continuing candidate left is *exhausted*.
4. **Election.** `total` = sum of continuing candidates' votes in the round.
   If a candidate has more than half of `total` (`votes * 2 > total`), they
   are elected and counting stops.
5. **No votes.** If `total` is 0, there is no winner and counting stops.
6. **Exclusion.** Otherwise, exclude the continuing candidate with the fewest
   votes. If several are tied on fewest:
   1. Look at earlier rounds, starting with the most recent. Keep only the
      tied candidates with the fewest votes in that round. Stop when one remains.
   2. If still tied after the first round, exclude the one whose ID comes
      **last** in plain code-point order. (A deterministic stand-in for drawing lots.)
7. Repeat from rule 3.

## Output

```json
{
  "election_id": "VIC-MELB-2026",
  "formal": 180,
  "informal": 0,
  "winner": "CHEN",
  "rounds": [
    {
      "round": 1,
      "counts": { "ALVAREZ": 40, "BROWN": 50, "CHEN": 60, "DIAZ": 30 },
      "exhausted": 0,
      "total": 180,
      "excluded": "DIAZ",
      "elected": null
    }
  ]
}
```

- `counts` lists continuing candidates only. Keys are compared after
  canonical sorting, so key order does not matter.
- `excluded` and `elected` are `null` when not applicable. `winner` is `null`
  if no one is elected.

## Comparison (publication gate)

The two outputs are compared as canonical JSON. Any difference, even one vote
in one round, sets the run to `BLOCKED`, writes to the audit log, and alerts
the State Electoral Officer. Only a `MATCHED` run, on a closed election, whose
CVR set has not changed since the run, can be published.
