"""Unit tests for Engine B (SR-15). Run: python3 -m unittest -v test_engine_b"""

import hashlib
import json
import os
import subprocess
import sys
import unittest
import uuid

sys.path.insert(0, os.path.dirname(__file__))
import engine_b  # noqa: E402


def make(candidates, ballots, eid="T"):
    cvrs = []
    for prefs in ballots:
        bid = str(uuid.uuid4())
        h = hashlib.sha384(("%s|%s|%s" % (bid, eid, ",".join(prefs))).encode()).hexdigest()
        cvrs.append({"ballot_id": bid, "preferences": prefs, "cvr_hash": h})
    return {"election_id": eid, "candidates": candidates, "cvrs": cvrs}


class EngineBTests(unittest.TestCase):
    def test_majority_first_round(self):
        r = engine_b.count(make(["A", "B"], [["A"], ["A"], ["B"]]))
        self.assertEqual(r["winner"], "A")
        self.assertEqual(len(r["rounds"]), 1)

    def test_preference_flow(self):
        ballots = [["A", "B"]] * 4 + [["B", "C"]] * 3 + [["C", "B"]] * 2
        r = engine_b.count(make(["A", "B", "C"], ballots))
        self.assertEqual(r["rounds"][0]["excluded"], "C")
        self.assertEqual(r["rounds"][1]["counts"], {"A": 4, "B": 5})
        self.assertEqual(r["winner"], "B")

    def test_backward_tie_break(self):
        ballots = [["A"]] * 5 + [["B"]] * 4 + [["D"]] * 3 + [["C", "D"], ["C", "A"]]
        r = engine_b.count(make(["A", "B", "C", "D"], ballots))
        self.assertEqual(r["rounds"][1]["excluded"], "D")
        self.assertEqual(r["winner"], "A")

    def test_last_id_tie_break(self):
        r = engine_b.count(make(["A", "B", "C"], [["A"], ["A"], ["B"], ["C"]]))
        self.assertEqual(r["rounds"][0]["excluded"], "C")

    def test_tampered_cvr_rejected(self):
        data = make(["A", "B"], [["A"], ["B"]])
        data["cvrs"][0]["preferences"] = ["B"]
        r = engine_b.count(data)
        self.assertEqual(r["error"], "INTEGRITY_FAILURE")

    def test_cli_reads_stdin_writes_stdout(self):
        data = make(["A", "B"], [["B"], ["B"], ["A"]])
        out = subprocess.run(
            [sys.executable, "-I", os.path.join(os.path.dirname(__file__), "engine_b.py")],
            input=json.dumps(data), capture_output=True, text=True, check=True,
        )
        self.assertEqual(json.loads(out.stdout)["winner"], "B")


if __name__ == "__main__":
    unittest.main()
