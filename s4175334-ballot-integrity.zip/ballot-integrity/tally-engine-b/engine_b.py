#!/usr/bin/env python3
"""SR-15 Engine B: independent preferential count in Python.

Owner: Muzammil Malek (s4175334)

Implements docs/counting-rules.md. Deliberately shares no code with Engine A
(server/src/tally/engineA.js). It also uses a different strategy: instead of
re-scanning every ballot each round, it keeps ballots grouped in "piles" by
their current candidate and only moves the pile of the excluded candidate.

Usage: reads the input JSON on stdin and writes the result JSON on stdout.
Uses only the standard library, so there is no third-party supply chain.
"""

import hashlib
import json
import sys


def _expected_hash(election_id, cvr):
    text = "%s|%s|%s" % (cvr["ballot_id"], election_id, ",".join(cvr["preferences"]))
    return hashlib.sha384(text.encode("utf-8")).hexdigest()


def _formal(prefs, valid):
    return (
        isinstance(prefs, list)
        and len(prefs) > 0
        and len(set(prefs)) == len(prefs)
        and all(p in valid for p in prefs)
    )


def _next_choice(prefs, start, continuing):
    """Index of the next continuing candidate at or after start, or None."""
    i = start
    while i < len(prefs):
        if prefs[i] in continuing:
            return i
        i += 1
    return None


def _break_tie(tied, past_rounds):
    remaining = sorted(tied)
    for earlier in reversed(past_rounds):
        if len(remaining) == 1:
            break
        fewest = min(earlier[c] for c in remaining)
        remaining = [c for c in remaining if earlier[c] == fewest]
    # Still tied: exclude the ID that sorts last.
    return max(remaining)


def count(data):
    election_id = data["election_id"]
    candidates = list(data["candidates"])
    cvrs = data["cvrs"]

    bad = sorted(c["ballot_id"] for c in cvrs if _expected_hash(election_id, c) != c["cvr_hash"])
    if bad:
        return {"error": "INTEGRITY_FAILURE", "ballot_ids": bad}

    valid = set(candidates)
    formal = [c["preferences"] for c in cvrs if _formal(c["preferences"], valid)]

    continuing = set(candidates)
    # piles[candidate] = list of (ballot index, position in that ballot)
    piles = {c: [] for c in candidates}
    exhausted = 0
    for idx, prefs in enumerate(formal):
        pos = _next_choice(prefs, 0, continuing)
        if pos is None:
            exhausted += 1
        else:
            piles[prefs[pos]].append((idx, pos))

    rounds = []
    past = []
    winner = None
    number = 0
    while True:
        number += 1
        tally = {c: len(piles[c]) for c in continuing}
        total = sum(tally.values())
        record = {
            "round": number,
            "counts": dict(tally),
            "exhausted": exhausted,
            "total": total,
            "excluded": None,
            "elected": None,
        }
        rounds.append(record)

        majority = [c for c, v in tally.items() if 2 * v > total]
        if majority:
            winner = majority[0]
            record["elected"] = winner
            break
        if total == 0:
            break

        low = min(tally.values())
        out = _break_tie([c for c, v in tally.items() if v == low], past)
        record["excluded"] = out
        past.append(tally)

        continuing.discard(out)
        moving = piles.pop(out)
        for idx, pos in moving:
            prefs = formal[idx]
            nxt = _next_choice(prefs, pos + 1, continuing)
            if nxt is None:
                exhausted += 1
            else:
                piles[prefs[nxt]].append((idx, nxt))

    return {
        "election_id": election_id,
        "formal": len(formal),
        "informal": len(cvrs) - len(formal),
        "winner": winner,
        "rounds": rounds,
    }


def main():
    data = json.load(sys.stdin)
    json.dump(count(data), sys.stdout)


if __name__ == "__main__":
    main()
