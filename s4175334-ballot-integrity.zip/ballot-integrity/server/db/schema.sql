-- Ballot Integrity subsystem schema (SR-13 to SR-16)
-- Owner: Muzammil Malek (s4175334)
--
-- Three schemas model three security domains. Each has its own connection
-- pool and connection string (ROLL_DATABASE_URL, BALLOT_DATABASE_URL,
-- OPS_DATABASE_URL), so they can be moved onto separate database servers on
-- separate subnets for SR-08 without code changes.
--
--   roll   - electoral roll and mark-off status (knows WHO voted)
--   ballot - cast vote records (knows WHAT was voted, never who)
--   ops    - terminals, elections, tally runs, alerts, audit

CREATE SCHEMA IF NOT EXISTS roll;
CREATE SCHEMA IF NOT EXISTS ballot;
CREATE SCHEMA IF NOT EXISTS ops;

-- ---------------------------------------------------------------- ops ----

CREATE TABLE IF NOT EXISTS ops.elections (
  election_id  TEXT PRIMARY KEY,
  name         TEXT   NOT NULL,
  candidates   TEXT[] NOT NULL CHECK (cardinality(candidates) >= 2),
  status       TEXT   NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'CLOSED')),
  closed_at    TIMESTAMPTZ
);

-- SR-14: each terminal's public signing key is registered at enrolment.
CREATE TABLE IF NOT EXISTS ops.terminals (
  terminal_id     TEXT PRIMARY KEY CHECK (terminal_id ~ '^[A-Za-z0-9_-]{3,40}$'),
  public_key_pem  TEXT NOT NULL,
  algorithm       TEXT NOT NULL DEFAULT 'Ed25519',
  polling_place   TEXT NOT NULL,
  registered_at   TIMESTAMPTZ NOT NULL DEFAULT now(),
  revoked         BOOLEAN NOT NULL DEFAULT FALSE
);

-- Placeholder audit table. Replace writes with Mmhachio's SR-09 secure
-- hash-chained logger when it is merged (see src/audit.js).
CREATE TABLE IF NOT EXISTS ops.audit_log (
  id      BIGSERIAL PRIMARY KEY,
  at      TIMESTAMPTZ(3) NOT NULL DEFAULT clock_timestamp(),
  actor   TEXT  NOT NULL,
  action  TEXT  NOT NULL,
  detail  JSONB NOT NULL DEFAULT '{}'::jsonb
);

-- SR-15: alerts raised to the State Electoral Officer.
CREATE TABLE IF NOT EXISTS ops.alerts (
  alert_id      UUID PRIMARY KEY,
  raised_at     TIMESTAMPTZ(3) NOT NULL DEFAULT clock_timestamp(),
  severity      TEXT NOT NULL CHECK (severity IN ('HIGH', 'CRITICAL')),
  subject       TEXT NOT NULL,
  detail        JSONB NOT NULL,
  delivered_via TEXT NOT NULL
);

-- SR-15: every N-version tally run and its comparison result.
CREATE TABLE IF NOT EXISTS ops.tally_runs (
  run_id        UUID PRIMARY KEY,
  election_id   TEXT NOT NULL REFERENCES ops.elections(election_id),
  started_at    TIMESTAMPTZ(3) NOT NULL DEFAULT clock_timestamp(),
  cvr_count     INT  NOT NULL,
  cvr_set_hash  TEXT NOT NULL,
  engine_a      JSONB NOT NULL,
  engine_b      JSONB NOT NULL,
  matched       BOOLEAN NOT NULL,
  discrepancy   JSONB,
  status        TEXT NOT NULL CHECK (status IN ('MATCHED', 'BLOCKED', 'PUBLISHED'))
);

CREATE TABLE IF NOT EXISTS ops.published_results (
  election_id   TEXT PRIMARY KEY REFERENCES ops.elections(election_id),
  run_id        UUID NOT NULL REFERENCES ops.tally_runs(run_id),
  result        JSONB NOT NULL,
  published_at  TIMESTAMPTZ(3) NOT NULL DEFAULT clock_timestamp()
);

-- --------------------------------------------------------------- roll ----

-- SR-13: one row per voter per election. Status moves from ELIGIBLE exactly
-- once, under a row lock. The ballot authorization token ID (jti) is NEVER
-- stored here, so a token cannot be traced back to a voter.
CREATE TABLE IF NOT EXISTS roll.electoral_roll (
  election_id             TEXT NOT NULL,
  voter_id                TEXT NOT NULL,
  full_name               TEXT NOT NULL,
  division                TEXT NOT NULL,
  status                  TEXT NOT NULL DEFAULT 'ELIGIBLE'
                          CHECK (status IN ('ELIGIBLE', 'TOKEN_ISSUED', 'DECLARATION_ACCEPTED')),
  marked_off_at           TIMESTAMPTZ,
  marked_off_by_terminal  TEXT,
  PRIMARY KEY (election_id, voter_id)
);

-- ------------------------------------------------------------- ballot ----

-- Cast vote records. No voter, terminal, batch or timestamp columns, so a
-- row cannot be linked to the voter who cast it (supports SR-05).
-- ballot_id is the primary key, so a retransmitted ballot is never counted
-- twice (SR-16).
CREATE TABLE IF NOT EXISTS ballot.ballots (
  ballot_id    UUID PRIMARY KEY,
  election_id  TEXT   NOT NULL,
  preferences  TEXT[] NOT NULL CHECK (cardinality(preferences) >= 1),
  cvr_hash     TEXT   NOT NULL CHECK (cvr_hash ~ '^[0-9a-f]{96}$')  -- SHA-384
);
CREATE INDEX IF NOT EXISTS ballots_election_idx ON ballot.ballots (election_id);

-- SR-13: each authorization token can be redeemed once. Deliberately no
-- timestamp, to avoid correlating redemption time with mark-off time.
CREATE TABLE IF NOT EXISTS ballot.spent_tokens (
  jti  UUID PRIMARY KEY
);

-- SR-14: every accepted batch and the signed receipt returned for it.
CREATE TABLE IF NOT EXISTS ballot.batches (
  batch_id           UUID PRIMARY KEY,
  terminal_id        TEXT NOT NULL,
  batch_hash         TEXT NOT NULL,
  ballot_count       INT  NOT NULL,
  accepted_count     INT  NOT NULL,
  received_at        TIMESTAMPTZ(3) NOT NULL DEFAULT clock_timestamp(),
  receipt            JSONB NOT NULL
);

-- SR-16: the last hash-chain link received from each terminal. The next
-- batch must continue from exactly this point.
CREATE TABLE IF NOT EXISTS ballot.terminal_chain (
  terminal_id  TEXT PRIMARY KEY,
  last_hash    TEXT NOT NULL CHECK (last_hash ~ '^[0-9a-f]{64}$'),
  updated_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);
