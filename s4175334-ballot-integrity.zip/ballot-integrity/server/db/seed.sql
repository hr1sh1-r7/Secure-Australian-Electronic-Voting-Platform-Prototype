-- Demo data only. All voters are fictional.
INSERT INTO ops.elections (election_id, name, candidates)
VALUES ('VIC-MELB-2026', 'Division of Melbourne (demo)', ARRAY['ALVAREZ', 'BROWN', 'CHEN', 'DIAZ'])
ON CONFLICT (election_id) DO NOTHING;

INSERT INTO roll.electoral_roll (election_id, voter_id, full_name, division)
SELECT 'VIC-MELB-2026',
       'V' || lpad(n::text, 4, '0'),
       'Demo Voter ' || n,
       'Melbourne'
FROM generate_series(1, 200) AS n
ON CONFLICT DO NOTHING;
