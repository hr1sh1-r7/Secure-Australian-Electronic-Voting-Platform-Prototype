// Test setup. Must be imported FIRST in each test file so the environment is
// set before any src/ module reads its configuration.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import pg from 'pg';
import { randomUUID, generateKeyPairSync, sign as cryptoSign } from 'node:crypto';

const testDb = process.env.TEST_DATABASE_URL ?? 'postgres://postgres@localhost:5432/ballot_integrity_test';
process.env.DATABASE_URL = testDb;
delete process.env.ROLL_DATABASE_URL;
delete process.env.BALLOT_DATABASE_URL;
delete process.env.OPS_DATABASE_URL;
process.env.KEYS_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'bi-keys-'));
process.env.ADMIN_API_TOKEN = 'test-admin-token-0123456789abcdef';
process.env.ENROLMENT_SECRET = 'test-enrolment-secret-0123456789ab';
process.env.DEMO_MODE = 'true';
process.env.NODE_ENV = 'test';
delete process.env.SEO_ALERT_WEBHOOK;

export const ELECTION = 'VIC-MELB-2026';
export const ADMIN = { authorization: `Bearer ${process.env.ADMIN_API_TOKEN}` };

const { canonicalize, genesisHash, computeEntryHash, batchSigningBytes } = await import('../../shared/canonical.js');

async function ensureDatabase() {
  const u = new URL(testDb);
  const name = u.pathname.slice(1);
  u.pathname = '/postgres';
  const admin = new pg.Client({ connectionString: u.toString() });
  await admin.connect();
  const { rowCount } = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [name]);
  if (!rowCount) await admin.query(`CREATE DATABASE "${name}"`);
  await admin.end();
}

export async function resetDb() {
  await ensureDatabase();
  const { initDb } = await import('../scripts/init-db.js');
  await initDb(testDb, { reset: true, seed: true });
  const { clearKeyCache } = await import('../src/terminals/registry.js');
  clearKeyCache();
}

export async function startServer() {
  const { createApp } = await import('../src/app.js');
  const server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  const base = `http://127.0.0.1:${server.address().port}`;
  return { base, close: () => new Promise((r) => server.close(r)) };
}

export async function post(base, route, body, headers = {}) {
  const res = await fetch(base + route, {
    method: 'POST',
    headers: { 'content-type': 'application/json', ...headers },
    body: typeof body === 'string' ? body : JSON.stringify(body),
  });
  return { status: res.status, body: await res.json() };
}

export async function get(base, route, headers = {}) {
  const res = await fetch(base + route, { headers });
  return { status: res.status, body: await res.json() };
}

// A simulated polling terminal with its own Ed25519 key.
export async function enrolTerminal(base, terminalId = `T-${randomUUID().slice(0, 8)}`) {
  const { privateKey, publicKey } = generateKeyPairSync('ed25519');
  const res = await post(
    base,
    '/api/terminals/register',
    { terminal_id: terminalId, public_key_pem: publicKey.export({ type: 'spki', format: 'pem' }), polling_place: 'Test Hall' },
    { 'x-enrolment-secret': process.env.ENROLMENT_SECRET },
  );
  if (res.status !== 201) throw new Error('enrol failed: ' + JSON.stringify(res.body));
  const term = {
    id: terminalId,
    privateKey,
    chainHead: genesisHash(terminalId),
    signBytes: (bytes) => cryptoSign(null, bytes, privateKey).toString('base64'),
  };
  return term;
}

export async function authorize(base, term, voterId, overrides = {}) {
  const fields = { terminal_id: term.id, election_id: ELECTION, voter_id: voterId, timestamp: new Date().toISOString(), ...overrides };
  const signature = term.signBytes(Buffer.from(canonicalize(fields)));
  return post(base, '/api/markoff/authorize', { ...fields, signature });
}

// Build a signed, hash-chained batch. Advances the terminal's chain head
// unless advance=false.
export function buildBatch(term, specs, { advance = true, sign = true } = {}) {
  let prev = term.chainHead;
  const chainStart = prev;
  const entries = specs.map((s) => {
    const entry = {
      ballot_id: s.ballot_id ?? randomUUID(),
      election_id: ELECTION,
      preferences: s.preferences ?? ['ALVAREZ', 'BROWN'],
      auth: s.token ? { type: 'token', token: s.token } : { type: 'declaration', voter_id: s.voter_id },
      queued_at: new Date().toISOString(),
      prev_hash: prev,
    };
    entry.entry_hash = computeEntryHash(entry);
    prev = entry.entry_hash;
    return entry;
  });
  const batch = {
    batch_id: randomUUID(),
    terminal_id: term.id,
    election_id: ELECTION,
    created_at: new Date().toISOString(),
    chain_start: chainStart,
    entries,
  };
  if (sign) batch.signature = term.signBytes(batchSigningBytes(batch));
  if (advance) term.chainHead = prev;
  return batch;
}

export async function shutdown() {
  const { closeAll } = await import('../src/db.js');
  await closeAll();
}

export { canonicalize, batchSigningBytes };
