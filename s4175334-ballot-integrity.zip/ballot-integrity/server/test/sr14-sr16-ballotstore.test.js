// SR-14 (signed batches + signed receipts) and SR-16 (store-and-forward, server side)
import {
  ELECTION, resetDb, startServer, enrolTerminal, authorize, buildBatch, post, get, shutdown,
  canonicalize, batchSigningBytes,
} from './helpers.js';
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { createPublicKey, verify as cryptoVerify, randomUUID } from 'node:crypto';

const { ballotDb, rollDb, opsDb } = await import('../src/db.js');

let srv;
let receiptKey;

before(async () => {
  await resetDb();
  srv = await startServer();
  const k = await get(srv.base, '/api/keys/receipt');
  receiptKey = createPublicKey(k.body.public_key_pem);
});
after(async () => {
  await srv.close();
  await shutdown();
});

let voterSeq = 20;
const nextVoter = () => `V${String(voterSeq++).padStart(4, '0')}`;
async function token(term) {
  return (await authorize(srv.base, term, nextVoter())).body.token;
}
const send = (batch) => post(srv.base, '/api/ballot-store/batches', batch);
function receiptVerifies(receipt) {
  const { signature, ...body } = receipt;
  return cryptoVerify(null, Buffer.from(canonicalize(body)), receiptKey, Buffer.from(signature, 'base64'));
}

test('valid signed batch is accepted and gets a signed receipt that verifies', async () => {
  const term = await enrolTerminal(srv.base);
  const batch = buildBatch(term, [{ token: await token(term) }, { token: await token(term) }]);
  const res = await send(batch);
  assert.equal(res.status, 201);
  assert.equal(res.body.receipt.ballot_count, 2);
  assert.equal(res.body.receipt.accepted.length, 2);
  assert.ok(receiptVerifies(res.body.receipt));
  assert.ok(res.body.processing_ms < 60_000);
});

test('a forged receipt fails verification', async () => {
  const term = await enrolTerminal(srv.base);
  const res = await send(buildBatch(term, [{ token: await token(term) }]));
  const forged = { ...res.body.receipt, ballot_count: 99 };
  assert.equal(receiptVerifies(forged), false);
});

test('unsigned batch is rejected', async () => {
  const term = await enrolTerminal(srv.base);
  const res = await send(buildBatch(term, [{ token: await token(term) }], { sign: false, advance: false }));
  assert.equal(res.status, 401);
  assert.equal(res.body.error, 'UNSIGNED');
});

test('batch altered after signing (one preference changed) is rejected', async () => {
  const term = await enrolTerminal(srv.base);
  const batch = buildBatch(term, [{ token: await token(term), preferences: ['ALVAREZ', 'BROWN'] }], { advance: false });
  batch.entries[0].preferences = ['BROWN', 'ALVAREZ'];
  const res = await send(batch);
  assert.equal(res.status, 401);
  assert.equal(res.body.error, 'BAD_SIGNATURE');
});

test('batch from an unregistered terminal is rejected', async () => {
  const term = await enrolTerminal(srv.base);
  const batch = buildBatch({ ...term, id: 'T-NOT-ENROLLED' }, [{ voter_id: nextVoter() }], { advance: false });
  const res = await send(batch);
  assert.equal(res.status, 401);
  assert.equal(res.body.error, 'UNKNOWN_OR_REVOKED_TERMINAL');
});

test('replayed batch_id with different content is rejected', async () => {
  const term = await enrolTerminal(srv.base);
  const first = buildBatch(term, [{ token: await token(term) }]);
  assert.equal((await send(first)).status, 201);
  const second = buildBatch(term, [{ token: await token(term) }], { sign: false });
  second.batch_id = first.batch_id;
  second.signature = term.signBytes(batchSigningBytes(second));
  const res = await send(second);
  assert.equal(res.status, 409);
  assert.equal(res.body.error, 'REPLAYED_BATCH_ID');
});

test('identical retransmission (lost receipt) returns the original receipt and counts nothing twice', async () => {
  const term = await enrolTerminal(srv.base);
  const batch = buildBatch(term, [{ token: await token(term) }]);
  const first = await send(batch);
  const again = await send(batch);
  assert.equal(again.status, 200);
  assert.equal(again.body.duplicate, true);
  assert.deepEqual(again.body.receipt, first.body.receipt);
  const { rows } = await ballotDb.query('SELECT count(*)::int AS n FROM ballot.ballots WHERE ballot_id = $1', [batch.entries[0].ballot_id]);
  assert.equal(rows[0].n, 1);
});

test('the same token cannot be redeemed twice', async () => {
  const term = await enrolTerminal(srv.base);
  const t = await token(term);
  await send(buildBatch(term, [{ token: t }]));
  const res = await send(buildBatch(term, [{ token: t }]));
  assert.equal(res.status, 201);
  assert.deepEqual(res.body.receipt.rejected.map((r) => r.reason), ['TOKEN_ALREADY_USED']);
});

test('a ballot_id sent again in a later batch is not counted twice (SR-16)', async () => {
  const term = await enrolTerminal(srv.base);
  const ballotId = randomUUID();
  await send(buildBatch(term, [{ ballot_id: ballotId, token: await token(term) }]));
  const res = await send(buildBatch(term, [{ ballot_id: ballotId, token: await token(term) }]));
  assert.deepEqual(res.body.receipt.rejected.map((r) => r.reason), ['DUPLICATE_BALLOT_ID']);
});

test('deleting a queued ballot from the middle breaks the hash chain and raises an alert (SR-16)', async () => {
  const term = await enrolTerminal(srv.base);
  const batch = buildBatch(term, [{ voter_id: nextVoter() }, { voter_id: nextVoter() }, { voter_id: nextVoter() }], { sign: false });
  batch.entries.splice(1, 1); // attacker removes one ballot from the local queue
  batch.signature = term.signBytes(batchSigningBytes(batch));
  const res = await send(batch);
  assert.equal(res.status, 409);
  assert.equal(res.body.error, 'CHAIN_BROKEN');
  const alerts = await opsDb.query("SELECT subject FROM ops.alerts WHERE subject LIKE $1", [`%${term.id}%`]);
  assert.equal(alerts.rowCount, 1);
});

test('a batch that skips earlier queue entries is rejected (SR-16)', async () => {
  const term = await enrolTerminal(srv.base);
  buildBatch(term, [{ voter_id: nextVoter() }]); // built but never sent
  const res = await send(buildBatch(term, [{ voter_id: nextVoter() }]));
  assert.equal(res.status, 409);
  assert.equal(res.body.error, 'CHAIN_BROKEN');
});

test('offline declaration ballot marks the voter off on arrival and stores no voter ID (SR-16)', async () => {
  const term = await enrolTerminal(srv.base);
  const voter = nextVoter();
  const batch = buildBatch(term, [{ voter_id: voter, preferences: ['CHEN', 'DIAZ'] }]);
  const res = await send(batch);
  assert.equal(res.body.receipt.accepted.length, 1);
  const roll = await rollDb.query('SELECT status FROM roll.electoral_roll WHERE election_id = $1 AND voter_id = $2', [ELECTION, voter]);
  assert.equal(roll.rows[0].status, 'DECLARATION_ACCEPTED');
  const stored = await ballotDb.query('SELECT * FROM ballot.ballots WHERE ballot_id = $1', [batch.entries[0].ballot_id]);
  assert.ok(!JSON.stringify(stored.rows[0]).includes(voter));
});

test('offline ballot from a voter who already voted online is discarded (SR-13 + SR-16)', async () => {
  const term = await enrolTerminal(srv.base);
  const voter = nextVoter();
  await authorize(srv.base, term, voter); // voted online elsewhere
  const res = await send(buildBatch(term, [{ voter_id: voter }]));
  assert.deepEqual(res.body.receipt.rejected.map((r) => r.reason), ['DECLARATION_ALREADY_MARKED_OFF']);
});

test('informal preferences are rejected per ballot', async () => {
  const term = await enrolTerminal(srv.base);
  const res = await send(buildBatch(term, [
    { voter_id: nextVoter(), preferences: ['ALVAREZ', 'ALVAREZ'] },
    { voter_id: nextVoter(), preferences: ['NOBODY'] },
  ]));
  assert.deepEqual(res.body.receipt.rejected.map((r) => r.reason), ['INFORMAL_PREFERENCES', 'INFORMAL_PREFERENCES']);
});

test('unexpected fields and injection-style input are rejected by the schema', async () => {
  const term = await enrolTerminal(srv.base);
  const batch = buildBatch(term, [{ voter_id: nextVoter() }], { advance: false });
  const res1 = await send({ ...batch, isAdmin: true });
  assert.equal(res1.status, 400);
  const evil = buildBatch(term, [{ voter_id: nextVoter(), preferences: ["ALVAREZ'; DROP TABLE ballot.ballots;--"] }], { advance: false });
  const res2 = await send(evil);
  assert.equal(res2.status, 400);
});
