// SR-13 unit tests: Atomic Single-Use Mark-off (Anti-Double Voting)
import { ELECTION, resetDb, startServer, enrolTerminal, authorize, shutdown } from './helpers.js';
import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { decodeJwt, decodeProtectedHeader } from 'jose';

const { verifyBallotToken, markOff } = await import('../src/markoff/service.js');
const { rollDb } = await import('../src/db.js');

let srv;
let term;

before(async () => {
  await resetDb();
  srv = await startServer();
  term = await enrolTerminal(srv.base);
});
after(async () => {
  await srv.close();
  await shutdown();
});

test('eligible voter is marked off and receives a token within 2 seconds', async () => {
  const res = await authorize(srv.base, term, 'V0001');
  assert.equal(res.status, 200);
  assert.ok(res.body.token);
  assert.ok(res.body.elapsed_ms < 2000, `took ${res.body.elapsed_ms} ms`);
  const { rows } = await rollDb.query(
    "SELECT status FROM roll.electoral_roll WHERE election_id = $1 AND voter_id = 'V0001'", [ELECTION]);
  assert.equal(rows[0].status, 'TOKEN_ISSUED');
});

test('second request for the same voter is rejected with 409 within 2 seconds', async () => {
  await authorize(srv.base, term, 'V0002');
  const again = await authorize(srv.base, term, 'V0002');
  assert.equal(again.status, 409);
  assert.equal(again.body.error, 'ALREADY_MARKED_OFF');
  assert.ok(again.body.elapsed_ms < 2000);
});

test('duplicate request from a different terminal (another polling place) is also rejected', async () => {
  const other = await enrolTerminal(srv.base);
  await authorize(srv.base, term, 'V0003');
  const res = await authorize(srv.base, other, 'V0003');
  assert.equal(res.status, 409);
});

test('50 concurrent requests for one voter produce exactly one token (no TOCTOU race)', async () => {
  const results = await Promise.all(
    Array.from({ length: 50 }, () => markOff({ electionId: ELECTION, voterId: 'V0004', terminalId: term.id, mode: 'TOKEN_ISSUED' })
      .then(() => 'ok', (e) => e.reason)),
  );
  assert.equal(results.filter((r) => r === 'ok').length, 1, JSON.stringify(results));
  for (const r of results.filter((x) => x !== 'ok')) {
    assert.ok(['ALREADY_MARKED_OFF', 'CONCURRENT_REQUEST'].includes(r), r);
  }
});

test('50 concurrent HTTP requests across 5 terminals produce exactly one 200', async () => {
  const terms = await Promise.all(Array.from({ length: 5 }, () => enrolTerminal(srv.base)));
  const results = await Promise.all(
    Array.from({ length: 50 }, (_, i) => authorize(srv.base, terms[i % 5], 'V0005')),
  );
  assert.equal(results.filter((r) => r.status === 200).length, 1);
  assert.ok(results.every((r) => r.status === 200 || r.status === 409));
});

test('voter not on the roll is rejected', async () => {
  const res = await authorize(srv.base, term, 'X9999');
  assert.equal(res.status, 404);
  assert.equal(res.body.error, 'NOT_ON_ROLL');
});

test('token carries no voter identity and is pinned to RS256', async () => {
  const res = await authorize(srv.base, term, 'V0006');
  const claims = decodeJwt(res.body.token);
  assert.equal(decodeProtectedHeader(res.body.token).alg, 'RS256');
  assert.ok(claims.jti);
  assert.equal(claims.sub, undefined);
  assert.ok(!JSON.stringify(claims).includes('V0006'));
});

test("token with 'alg: none' is rejected", async () => {
  const res = await authorize(srv.base, term, 'V0007');
  const [, payload] = res.body.token.split('.');
  const header = Buffer.from(JSON.stringify({ alg: 'none', typ: 'JWT' })).toString('base64url');
  await assert.rejects(verifyBallotToken(`${header}.${payload}.`, ELECTION));
});

test('token with a tampered payload is rejected', async () => {
  const res = await authorize(srv.base, term, 'V0008');
  const [h, p, s] = res.body.token.split('.');
  const claims = JSON.parse(Buffer.from(p, 'base64url'));
  claims.eid = 'OTHER-ELECTION';
  const forged = `${h}.${Buffer.from(JSON.stringify(claims)).toString('base64url')}.${s}`;
  await assert.rejects(verifyBallotToken(forged, ELECTION));
});

test('token for a different election is rejected', async () => {
  const res = await authorize(srv.base, term, 'V0009');
  await assert.rejects(verifyBallotToken(res.body.token, 'SOME-OTHER-ELECTION'));
});

test('unsigned, forged or stale mark-off requests are rejected', async () => {
  const forger = await enrolTerminal(srv.base);
  // Signed by a different terminal's key while claiming to be `term`
  const forged = await authorize(srv.base, { ...forger, id: term.id }, 'V0010');
  assert.equal(forged.status, 401);
  // Timestamp outside the 60 s window (replayed old request)
  const stale = await authorize(srv.base, term, 'V0010', { timestamp: new Date(Date.now() - 5 * 60_000).toISOString() });
  assert.equal(stale.status, 401);
  // The voter must still be eligible after both rejected attempts
  const ok = await authorize(srv.base, term, 'V0010');
  assert.equal(ok.status, 200);
});
