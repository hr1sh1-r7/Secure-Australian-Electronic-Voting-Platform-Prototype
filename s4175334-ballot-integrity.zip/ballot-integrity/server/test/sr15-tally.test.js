// SR-15 unit tests: Independent N-Version Recount Engine
import { ELECTION, ADMIN, resetDb, startServer, enrolTerminal, buildBatch, post, get, shutdown } from './helpers.js';
import { test, before, after, describe } from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';

const { countEngineA } = await import('../src/tally/engineA.js');
const { countEngineB } = await import('../src/tally/engineB.js');
const { cvrHash } = await import('../src/ballotstore/cvr.js');
const { canonicalize } = await import('../../shared/canonical.js');
const { ballotDb, opsDb } = await import('../src/db.js');

function election(candidates, ballots, id = 'TEST') {
  return {
    election_id: id,
    candidates,
    cvrs: ballots.map((preferences) => {
      const ballot_id = randomUUID();
      return { ballot_id, preferences, cvr_hash: cvrHash(ballot_id, id, preferences) };
    }),
  };
}
const times = (n, prefs) => Array.from({ length: n }, () => prefs);

async function both(input) {
  const a = countEngineA(input);
  const b = await countEngineB(input);
  assert.equal(canonicalize(a), canonicalize(b), 'engines disagree');
  return a;
}

describe('known-answer elections (both engines must agree and be correct)', () => {
  test('outright majority in round 1', async () => {
    const r = await both(election(['A', 'B', 'C'], [...times(3, ['A']), ['B'], ['C']]));
    assert.equal(r.winner, 'A');
    assert.equal(r.rounds.length, 1);
  });

  test('preferences flow on exclusion', async () => {
    const r = await both(election(['A', 'B', 'C'], [...times(4, ['A', 'B']), ...times(3, ['B', 'C']), ...times(2, ['C', 'B'])]));
    assert.deepEqual(r.rounds.map((x) => x.excluded), ['C', null]);
    assert.deepEqual(r.rounds[1].counts, { A: 4, B: 5 });
    assert.equal(r.winner, 'B');
  });

  test('tie for last is broken by looking back at earlier rounds', async () => {
    const r = await both(election(['A', 'B', 'C', 'D'], [
      ...times(5, ['A']), ...times(4, ['B']), ...times(3, ['D']), ['C', 'D'], ['C', 'A'],
    ]));
    assert.deepEqual(r.rounds[1].counts, { A: 6, B: 4, D: 4 });
    assert.equal(r.rounds[1].excluded, 'D'); // D had fewer votes in round 1
    assert.equal(r.rounds[2].exhausted, 4);
    assert.equal(r.winner, 'A');
  });

  test('tie with no earlier round excludes the ID that sorts last', async () => {
    const r = await both(election(['A', 'B', 'C'], [...times(2, ['A']), ['B'], ['C']]));
    assert.equal(r.rounds[0].excluded, 'C');
    assert.equal(r.winner, 'A');
  });

  test('informal ballots are counted separately and ignored', async () => {
    const r = await both(election(['A', 'B'], [['A'], ['A', 'A'], ['Z'], [], ['B'], ['A']]));
    assert.equal(r.informal, 3);
    assert.equal(r.formal, 3);
    assert.equal(r.winner, 'A');
  });

  test('no ballots means no winner', async () => {
    const r = await both(election(['A', 'B'], []));
    assert.equal(r.winner, null);
  });

  test('a tampered CVR stops both engines before counting', async () => {
    const input = election(['A', 'B'], [['A'], ['B'], ['A']]);
    input.cvrs[1].preferences = ['A']; // changed without updating the SHA-384 hash
    const a = await both(input);
    assert.equal(a.error, 'INTEGRITY_FAILURE');
    assert.deepEqual(a.ballot_ids, [input.cvrs[1].ballot_id]);
  });
});

test('engines agree on 150 random elections (differential test)', async () => {
  let seed = 20261025;
  const rand = () => ((seed = (seed * 1103515245 + 12345) % 2 ** 31) / 2 ** 31);
  const pick = (n) => Math.floor(rand() * n);
  for (let e = 0; e < 150; e++) {
    const candidates = ['ALVAREZ', 'BROWN', 'CHEN', 'DIAZ', 'EVANS', 'FONG'].slice(0, 2 + pick(5));
    const ballots = Array.from({ length: pick(90) }, () => {
      const shuffled = [...candidates].sort(() => rand() - 0.5);
      const prefs = shuffled.slice(0, 1 + pick(candidates.length));
      if (rand() < 0.03) prefs.push(prefs[0]); // occasional informal ballot
      return prefs;
    });
    await both(election(candidates, ballots, `RND-${e}`));
  }
});

describe('publication gate (API)', () => {
  let srv;
  let runId;
  before(async () => {
    await resetDb();
    srv = await startServer();
    const term = await enrolTerminal(srv.base);
    const prefs = [['CHEN', 'ALVAREZ'], ['CHEN'], ['ALVAREZ', 'BROWN'], ['BROWN', 'CHEN'], ['DIAZ', 'BROWN'], ['CHEN', 'DIAZ'], ['ALVAREZ']];
    const res = await post(srv.base, '/api/ballot-store/batches',
      buildBatch(term, prefs.map((p, i) => ({ voter_id: `V${String(100 + i).padStart(4, '0')}`, preferences: p }))));
    assert.equal(res.body.receipt.accepted.length, prefs.length);
  });
  after(async () => {
    await srv.close();
    await shutdown();
  });

  test('admin endpoints require authentication', async () => {
    const res = await post(srv.base, `/api/admin/tally/${ELECTION}/run`, {});
    assert.equal(res.status, 401);
  });

  test('a one-vote discrepancy blocks publication and alerts the State Electoral Officer', async () => {
    const run = await post(srv.base, `/api/admin/tally/${ELECTION}/run`, { simulateFault: true }, ADMIN);
    assert.equal(run.body.status, 'BLOCKED');
    assert.equal(run.body.discrepancy.type, 'VOTE_COUNT_MISMATCH');
    assert.equal(run.body.discrepancy.diffs[0].engineB - run.body.discrepancy.diffs[0].engineA, 1);
    assert.ok(run.body.alert.alertId);
    const alerts = await get(srv.base, '/api/admin/alerts', ADMIN);
    assert.match(alerts.body[0].subject, /publication blocked/);
    const pub = await post(srv.base, `/api/admin/tally/runs/${run.body.runId}/publish`, {}, ADMIN);
    assert.equal(pub.status, 409);
    assert.equal(pub.body.error, 'RUN_BLOCKED_BY_DISCREPANCY');
  });

  test('a matched run cannot be published while the election is open', async () => {
    const run = await post(srv.base, `/api/admin/tally/${ELECTION}/run`, {}, ADMIN);
    assert.equal(run.body.status, 'MATCHED');
    runId = run.body.runId;
    const pub = await post(srv.base, `/api/admin/tally/runs/${runId}/publish`, {}, ADMIN);
    assert.equal(pub.body.error, 'ELECTION_STILL_OPEN');
  });

  test('ballots inserted after the count make the run unpublishable', async () => {
    await post(srv.base, `/api/admin/elections/${ELECTION}/close`, {}, ADMIN);
    const id = randomUUID();
    await ballotDb.query('INSERT INTO ballot.ballots VALUES ($1, $2, $3, $4)', [id, ELECTION, ['DIAZ'], cvrHash(id, ELECTION, ['DIAZ'])]);
    const pub = await post(srv.base, `/api/admin/tally/runs/${runId}/publish`, {}, ADMIN);
    assert.equal(pub.body.error, 'BALLOTS_CHANGED_SINCE_COUNT');
    await ballotDb.query('DELETE FROM ballot.ballots WHERE ballot_id = $1', [id]);
  });

  test('a matched run on a closed election publishes exactly once', async () => {
    const pub = await post(srv.base, `/api/admin/tally/runs/${runId}/publish`, {}, ADMIN);
    assert.equal(pub.status, 200);
    assert.equal(pub.body.winner, 'CHEN');
    const again = await post(srv.base, `/api/admin/tally/runs/${runId}/publish`, {}, ADMIN);
    assert.equal(again.status, 409);
    const pubRes = await get(srv.base, `/api/results/${ELECTION}`);
    assert.equal(pubRes.body.result.winner, 'CHEN');
    const audit = await opsDb.query("SELECT count(*)::int AS n FROM ops.audit_log WHERE action = 'RESULT_PUBLISHED'");
    assert.equal(audit.rows[0].n, 1);
  });
});
