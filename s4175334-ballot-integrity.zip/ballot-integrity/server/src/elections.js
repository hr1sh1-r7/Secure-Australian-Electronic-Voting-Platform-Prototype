import { opsDb } from './db.js';

export async function getElection(electionId) {
  const { rows } = await opsDb.query(
    'SELECT election_id, name, candidates, status, closed_at FROM ops.elections WHERE election_id = $1',
    [electionId],
  );
  return rows[0] ?? null;
}

export async function closeElection(electionId) {
  const { rowCount } = await opsDb.query(
    `UPDATE ops.elections SET status = 'CLOSED', closed_at = now()
     WHERE election_id = $1 AND status = 'OPEN'`,
    [electionId],
  );
  return rowCount === 1;
}

// A formal preference list: at least one candidate, all known, no repeats.
export function validatePreferences(preferences, candidates) {
  if (!Array.isArray(preferences) || preferences.length === 0) return false;
  if (preferences.length > candidates.length) return false;
  const known = new Set(candidates);
  const seen = new Set();
  for (const p of preferences) {
    if (!known.has(p) || seen.has(p)) return false;
    seen.add(p);
  }
  return true;
}
