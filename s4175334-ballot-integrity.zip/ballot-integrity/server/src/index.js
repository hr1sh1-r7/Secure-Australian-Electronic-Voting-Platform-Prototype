import { createApp } from './app.js';
import { config, assertConfig } from './config.js';
import { getKeys } from './crypto/keys.js';

assertConfig();
getKeys(); // fail fast if keys are missing

createApp().listen(config.port, () => {
  console.log(`Ballot Integrity server on http://localhost:${config.port}  (admin: /admin/)`);
  if (config.demoMode) console.log('DEMO_MODE is on: fault injection is available. Never use in production.');
});
