// Audit adapter. Owner: Muzammil Malek (s4175334)
//
// Every security event in SR-13 to SR-16 goes through this one function.
// It writes to a simple table for now. When Mmhachio's SR-09 hash-chained
// append-only logger is merged, change only the body of audit() to call it.

import { opsDb } from './db.js';

export async function audit(actor, action, detail = {}) {
  try {
    await opsDb.query(
      'INSERT INTO ops.audit_log (actor, action, detail) VALUES ($1, $2, $3)',
      [actor, action, detail],
    );
  } catch (err) {
    // Auditing must never be silently lost: surface it loudly.
    console.error('[AUDIT WRITE FAILED]', action, err.message);
  }
}
