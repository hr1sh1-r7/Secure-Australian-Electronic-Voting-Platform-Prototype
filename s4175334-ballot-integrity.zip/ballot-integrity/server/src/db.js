import pg from 'pg';
import { config } from './config.js';

// One pool per security domain (supports SR-08 subnet segregation).
export const rollDb = new pg.Pool({ connectionString: config.rollDatabaseUrl, max: 20 });
export const ballotDb = new pg.Pool({ connectionString: config.ballotDatabaseUrl, max: 10 });
export const opsDb = new pg.Pool({ connectionString: config.opsDatabaseUrl, max: 10 });

export async function closeAll() {
  await Promise.all([rollDb.end(), ballotDb.end(), opsDb.end()]);
}

// Run fn inside a transaction on a dedicated client.
export async function withTransaction(pool, isolation, fn) {
  const client = await pool.connect();
  try {
    await client.query(`BEGIN ISOLATION LEVEL ${isolation}`);
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}
