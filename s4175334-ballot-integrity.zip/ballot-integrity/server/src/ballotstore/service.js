// SR-14: TPM-Signed Vote Batches & Signed Acknowledgement
// SR-16: Offline Store-and-Forward Voting Continuity (server side)
// Owner: Muzammil Malek (s4175334)
//
// Every batch goes through these gates, in order:
//   1. Strict schema validation              -> 400 MALFORMED_BATCH
//   2. Terminal signature (Ed25519)          -> 401 UNSIGNED / BAD_SIGNATURE / UNKNOWN_TERMINAL
//   3. Replay check on batch_id              -> 409 REPLAYED_BATCH_ID (same bytes = old receipt)
//   4. Election open                         -> 409 ELECTION_NOT_OPEN
//   5. Hash chain continuity (SR-16)         -> 409 CHAIN_BROKEN (+ alert)
//   6. Per ballot: formal preferences, unique ballot_id, single-use token
//      or offline declaration mark-off       -> listed as rejected in receipt
// Accepted batches get a receipt signed with the Ballot Store's Ed25519 key.

import { sign as cryptoSign } from 'node:crypto';
import { ballotDb, withTransaction } from '../db.js';
import { getKeys } from '../crypto/keys.js';
import { audit } from '../audit.js';
import { alertStateElectoralOfficer } from '../alerts.js';
import { getElection, validatePreferences } from '../elections.js';
import { verifyTerminalSignature } from '../terminals/registry.js';
import { verifyBallotToken, markOff, MarkOffRefused } from '../markoff/service.js';
import { batchSchema } from './schema.js';
import { cvrHash } from './cvr.js';
import {
  canonicalize,
  sha256Hex,
  genesisHash,
  computeEntryHash,
  batchSigningBytes,
} from '../../../shared/canonical.js';

export class BatchRejected extends Error {
  constructor(reason, status, detail = {}) {
    super(reason);
    this.reason = reason;
    this.status = status;
    this.detail = detail;
  }
}

function signReceipt(body) {
  const { receiptPrivateKey, receiptKid } = getKeys();
  const withSigner = { ...body, signer: receiptKid };
  const signature = cryptoSign(null, Buffer.from(canonicalize(withSigner)), receiptPrivateKey).toString('base64');
  return { ...withSigner, signature };
}

function checkChain(batch, expectedStart) {
  if (batch.chain_start !== expectedStart) {
    return { ok: false, at: 0, why: 'chain_start does not continue from the last received entry' };
  }
  let prev = expectedStart;
  for (let i = 0; i < batch.entries.length; i++) {
    const entry = batch.entries[i];
    if (entry.prev_hash !== prev) return { ok: false, at: i, why: 'prev_hash link missing' };
    if (computeEntryHash(entry) !== entry.entry_hash) return { ok: false, at: i, why: 'entry_hash mismatch' };
    prev = entry.entry_hash;
  }
  return { ok: true, last: prev };
}

export async function processBatch(rawBatch) {
  const started = performance.now();

  // 1. Schema
  const parsed = batchSchema.safeParse(rawBatch);
  if (!parsed.success) {
    throw new BatchRejected('MALFORMED_BATCH', 400, { issues: parsed.error.issues.slice(0, 5).map((i) => i.path.join('.')) });
  }
  const batch = parsed.data;
  const terminalId = batch.terminal_id;
  const signingBytes = batchSigningBytes(batch);

  // 2. Signature
  const sig = await verifyTerminalSignature(terminalId, signingBytes, batch.signature);
  if (!sig.ok) {
    await audit(terminalId, 'BATCH_REJECTED', { batchId: batch.batch_id, reason: sig.reason });
    throw new BatchRejected(sig.reason, 401);
  }
  const batchHash = sha256Hex(signingBytes);

  // 3. Replay / idempotent retransmission
  const prior = await ballotDb.query('SELECT batch_hash, receipt FROM ballot.batches WHERE batch_id = $1', [batch.batch_id]);
  if (prior.rows.length) {
    if (prior.rows[0].batch_hash === batchHash) {
      // Terminal never got our receipt (e.g. network dropped). Same bytes: resend it.
      return { receipt: prior.rows[0].receipt, duplicate: true, processingMs: Math.round(performance.now() - started) };
    }
    await audit(terminalId, 'BATCH_REJECTED', { batchId: batch.batch_id, reason: 'REPLAYED_BATCH_ID' });
    throw new BatchRejected('REPLAYED_BATCH_ID', 409);
  }

  // 4. Election
  const election = await getElection(batch.election_id);
  if (!election || election.status !== 'OPEN') {
    throw new BatchRejected('ELECTION_NOT_OPEN', 409);
  }
  if (batch.entries.some((e) => e.election_id !== batch.election_id)) {
    throw new BatchRejected('MIXED_ELECTIONS', 400);
  }

  const accepted = [];
  const rejected = [];

  const receipt = await withTransaction(ballotDb, 'READ COMMITTED', async (client) => {
    // 5. Hash chain. Lock this terminal's chain row so two batches from the
    // same terminal are processed strictly one after another.
    await client.query(
      'INSERT INTO ballot.terminal_chain (terminal_id, last_hash) VALUES ($1, $2) ON CONFLICT DO NOTHING',
      [terminalId, genesisHash(terminalId)],
    );
    const chainRow = await client.query(
      'SELECT last_hash FROM ballot.terminal_chain WHERE terminal_id = $1 FOR UPDATE',
      [terminalId],
    );
    const chain = checkChain(batch, chainRow.rows[0].last_hash);
    if (!chain.ok) {
      throw new BatchRejected('CHAIN_BROKEN', 409, { entryIndex: chain.at, why: chain.why });
    }

    // 6. Ballots
    for (const entry of batch.entries) {
      const reason = await acceptEntry(client, entry, election, terminalId);
      if (reason) rejected.push({ ballot_id: entry.ballot_id, reason });
      else accepted.push(entry.ballot_id);
    }

    await client.query(
      'UPDATE ballot.terminal_chain SET last_hash = $2, updated_at = now() WHERE terminal_id = $1',
      [terminalId, chain.last],
    );

    const signed = signReceipt({
      batch_id: batch.batch_id,
      terminal_id: terminalId,
      election_id: batch.election_id,
      batch_hash: batchHash,
      ballot_count: batch.entries.length,
      accepted,
      rejected,
      received_at: new Date().toISOString(),
    });
    await client.query(
      `INSERT INTO ballot.batches (batch_id, terminal_id, batch_hash, ballot_count, accepted_count, receipt)
       VALUES ($1, $2, $3, $4, $5, $6)`,
      [batch.batch_id, terminalId, batchHash, batch.entries.length, accepted.length, signed],
    );
    return signed;
  }).catch(async (err) => {
    if (err instanceof BatchRejected && err.reason === 'CHAIN_BROKEN') {
      await audit(terminalId, 'BATCH_REJECTED', { batchId: batch.batch_id, reason: err.reason, ...err.detail });
      // A broken chain means queued ballots were deleted, reordered or edited
      // on the terminal: escalate.
      await alertStateElectoralOfficer({
        severity: 'HIGH',
        subject: `Offline queue hash chain broken on terminal ${terminalId}`,
        detail: { terminalId, batchId: batch.batch_id, ...err.detail },
      });
    }
    throw err;
  });

  const processingMs = Math.round(performance.now() - started);
  await audit(terminalId, 'BATCH_ACCEPTED', {
    batchId: batch.batch_id,
    ballots: batch.entries.length,
    accepted: accepted.length,
    rejected: rejected.length,
    processingMs,
  });
  return { receipt, duplicate: false, processingMs };
}

// Returns null if the ballot was stored, otherwise the rejection reason.
async function acceptEntry(client, entry, election, terminalId) {
  if (!validatePreferences(entry.preferences, election.candidates)) return 'INFORMAL_PREFERENCES';

  const exists = await client.query('SELECT 1 FROM ballot.ballots WHERE ballot_id = $1', [entry.ballot_id]);
  if (exists.rows.length) return 'DUPLICATE_BALLOT_ID';

  if (entry.auth.type === 'token') {
    let payload;
    try {
      payload = await verifyBallotToken(entry.auth.token, election.election_id);
    } catch {
      return 'INVALID_TOKEN';
    }
    // Single use: the primary key makes the second redemption a no-op.
    const spent = await client.query(
      'INSERT INTO ballot.spent_tokens (jti) VALUES ($1) ON CONFLICT DO NOTHING RETURNING jti',
      [payload.jti],
    );
    if (spent.rowCount === 0) return 'TOKEN_ALREADY_USED';
  } else {
    // Offline ballot (SR-16): the voter could not be marked off at the time,
    // so mark them off now. If they already voted elsewhere, the ballot is
    // discarded unopened. The voter ID is used here and then dropped; it is
    // never written to the ballot schema.
    try {
      await markOff({
        electionId: election.election_id,
        voterId: entry.auth.voter_id,
        terminalId,
        mode: 'DECLARATION_ACCEPTED',
      });
    } catch (err) {
      if (err instanceof MarkOffRefused) return `DECLARATION_${err.reason}`;
      throw err;
    }
  }

  await client.query(
    'INSERT INTO ballot.ballots (ballot_id, election_id, preferences, cvr_hash) VALUES ($1, $2, $3, $4)',
    [entry.ballot_id, entry.election_id, entry.preferences, cvrHash(entry.ballot_id, entry.election_id, entry.preferences)],
  );
  return null;
}
