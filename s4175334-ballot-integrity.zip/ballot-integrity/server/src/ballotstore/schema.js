// Strict allow-list schemas for everything a terminal can send (SR-14, SR-16).
// z.strictObject rejects any unexpected field instead of silently ignoring it.
// Zod >= 4.6.6 is required (GHSA-mrhx-c7xc-m3w5, found by npm audit in CI).
import { z } from 'zod';
import { config } from '../config.js';

const uuid = z.uuid();
const hex64 = z.string().regex(/^[0-9a-f]{64}$/);
const terminalId = z.string().regex(/^[A-Za-z0-9_-]{3,40}$/);
const electionId = z.string().regex(/^[A-Za-z0-9_-]{3,40}$/);
const voterId = z.string().regex(/^[A-Za-z0-9]{3,20}$/);
const candidateId = z.string().regex(/^[A-Z0-9_-]{1,32}$/);
const isoTime = z.iso.datetime();

const tokenAuth = z.strictObject({ type: z.literal('token'), token: z.string().min(20).max(4096) });
const declarationAuth = z.strictObject({ type: z.literal('declaration'), voter_id: voterId });

export const entrySchema = z.strictObject({
  ballot_id: uuid,
  election_id: electionId,
  preferences: z.array(candidateId).min(1).max(64),
  auth: z.discriminatedUnion('type', [tokenAuth, declarationAuth]),
  queued_at: isoTime,
  prev_hash: hex64,
  entry_hash: hex64,
});

export const batchSchema = z.strictObject({
  batch_id: uuid,
  terminal_id: terminalId,
  election_id: electionId,
  created_at: isoTime,
  chain_start: hex64,
  entries: z.array(entrySchema).min(1).max(config.maxBatchEntries),
  signature: z.string().max(200).optional(),
});

export const authorizeRequestSchema = z.strictObject({
  terminal_id: terminalId,
  election_id: electionId,
  voter_id: voterId,
  timestamp: isoTime,
  signature: z.string().max(200),
});

export const registerSchema = z.strictObject({
  terminal_id: terminalId,
  public_key_pem: z.string().min(50).max(1000),
  polling_place: z.string().min(2).max(100),
});
