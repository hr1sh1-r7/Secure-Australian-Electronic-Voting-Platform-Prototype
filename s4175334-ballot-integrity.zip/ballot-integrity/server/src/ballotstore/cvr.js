// Cast Vote Record integrity hash (ties into Mmhachio's SR-10).
// The exact same string format is re-implemented independently in the Python
// engine B, and both tally engines re-check every hash before counting.
// Candidate IDs are restricted to [A-Z0-9_-] so '|' and ',' cannot be injected.

import { createHash } from 'node:crypto';

export function cvrHash(ballotId, electionId, preferences) {
  return createHash('sha384')
    .update(`${ballotId}|${electionId}|${preferences.join(',')}`, 'utf8')
    .digest('hex');
}
