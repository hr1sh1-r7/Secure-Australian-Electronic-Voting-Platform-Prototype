import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const env = process.env;

const defaultDb = env.DATABASE_URL ?? 'postgres://postgres@localhost:5432/ballot_integrity';

export const config = {
  port: Number(env.PORT ?? 3000),
  production: env.NODE_ENV === 'production',

  // Separate connection strings per security domain (supports SR-08).
  rollDatabaseUrl: env.ROLL_DATABASE_URL ?? defaultDb,
  ballotDatabaseUrl: env.BALLOT_DATABASE_URL ?? defaultDb,
  opsDatabaseUrl: env.OPS_DATABASE_URL ?? defaultDb,

  // Keys live outside source control. Dev keys are generated on first run.
  keysDir: env.KEYS_DIR ?? path.resolve(here, '..', 'keys'),

  // Placeholder credentials until the team's SR-01/SR-02 auth is merged.
  adminApiToken: env.ADMIN_API_TOKEN ?? '',
  enrolmentSecret: env.ENROLMENT_SECRET ?? '',

  // SR-13
  tokenIssuer: 'aec-markoff-service',
  tokenAudience: 'aec-ballot-store',
  tokenTtlSeconds: 600,
  requestClockSkewSeconds: 60,

  // SR-14
  maxBatchEntries: 500,

  // SR-15
  pythonBin: env.PYTHON_BIN ?? 'python3',
  engineBPath: env.ENGINE_B_PATH ?? path.resolve(here, '..', '..', 'tally-engine-b', 'engine_b.py'),
  engineTimeoutMs: 5 * 60 * 1000,
  seoAlertWebhook: env.SEO_ALERT_WEBHOOK ?? '',

  // Enables the "inject discrepancy" button for the demo. Never in production.
  demoMode: env.DEMO_MODE === 'true' && env.NODE_ENV !== 'production',
};

export function assertConfig() {
  const problems = [];
  if (config.adminApiToken.length < 24) problems.push('ADMIN_API_TOKEN must be set (24+ characters)');
  if (config.enrolmentSecret.length < 24) problems.push('ENROLMENT_SECRET must be set (24+ characters)');
  if (problems.length) {
    throw new Error('Configuration error:\n - ' + problems.join('\n - '));
  }
}
