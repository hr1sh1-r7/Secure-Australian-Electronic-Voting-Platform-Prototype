// Server-side keys. Owner: Muzammil Malek (s4175334)
//
//  - Mark-off token key (RS256): signs single-use ballot authorization
//    tokens (SR-13). RS256 matches the team's SR-02 JWT standard.
//  - Ballot Store receipt key (Ed25519): signs batch receipts (SR-14).
//
// Private keys are read from KEYS_DIR and are never committed. Outside
// production, missing keys are generated on first run for convenience.
// In production they would be held in an HSM or a cloud KMS.

import fs from 'node:fs';
import path from 'node:path';
import { generateKeyPairSync, createPrivateKey, createPublicKey } from 'node:crypto';
import { config } from '../config.js';

let cached = null;

function loadOrCreate(name, generate) {
  const privPath = path.join(config.keysDir, `${name}.private.pem`);
  if (!fs.existsSync(privPath)) {
    if (config.production) {
      throw new Error(`Missing key ${privPath}. Keys must be provisioned in production.`);
    }
    fs.mkdirSync(config.keysDir, { recursive: true, mode: 0o700 });
    const { privateKey } = generate();
    fs.writeFileSync(privPath, privateKey.export({ type: 'pkcs8', format: 'pem' }), { mode: 0o600 });
  }
  const privateKey = createPrivateKey(fs.readFileSync(privPath));
  return { privateKey, publicKey: createPublicKey(privateKey) };
}

export function getKeys() {
  if (!cached) {
    const token = loadOrCreate('markoff-token-rs256', () =>
      generateKeyPairSync('rsa', { modulusLength: 3072 }),
    );
    const receipt = loadOrCreate('ballot-store-receipt-ed25519', () =>
      generateKeyPairSync('ed25519'),
    );
    cached = {
      tokenPrivateKey: token.privateKey,
      tokenPublicKey: token.publicKey,
      tokenKid: 'markoff-rs256-1',
      receiptPrivateKey: receipt.privateKey,
      receiptPublicKey: receipt.publicKey,
      receiptPublicKeyPem: receipt.publicKey.export({ type: 'spki', format: 'pem' }),
      receiptKid: 'ballot-store-ed25519-1',
    };
  }
  return cached;
}
