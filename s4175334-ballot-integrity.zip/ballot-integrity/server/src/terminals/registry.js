// Terminal registry and signature verification (SR-14). Owner: Muzammil Malek (s4175334)
//
// Each polling terminal holds a private signing key that never leaves the
// device. Only its public key is registered here at enrolment. Everything a
// terminal sends (mark-off requests and vote batches) is signed with it.

import { createPublicKey, verify as cryptoVerify, timingSafeEqual } from 'node:crypto';
import { opsDb } from '../db.js';
import { config } from '../config.js';
import { canonicalize } from '../../../shared/canonical.js';

const keyCache = new Map();

export function secretsMatch(provided, expected) {
  if (typeof provided !== 'string' || !expected) return false;
  const a = Buffer.from(provided);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export async function registerTerminal({ terminalId, publicKeyPem, pollingPlace }) {
  const key = createPublicKey(publicKeyPem); // throws on malformed PEM
  if (key.asymmetricKeyType !== 'ed25519') {
    throw Object.assign(new Error('Terminal key must be Ed25519'), { status: 400 });
  }
  const normalised = key.export({ type: 'spki', format: 'pem' });
  // A terminal ID can only be enrolled once; re-keying needs an admin.
  const { rowCount } = await opsDb.query(
    `INSERT INTO ops.terminals (terminal_id, public_key_pem, polling_place)
     VALUES ($1, $2, $3) ON CONFLICT (terminal_id) DO NOTHING`,
    [terminalId, normalised, pollingPlace],
  );
  if (rowCount === 0) {
    const existing = await opsDb.query(
      'SELECT public_key_pem FROM ops.terminals WHERE terminal_id = $1',
      [terminalId],
    );
    // Same key re-enrolling (e.g. terminal restart) is harmless.
    if (existing.rows[0]?.public_key_pem !== normalised) {
      throw Object.assign(new Error('Terminal ID already enrolled with a different key'), { status: 409 });
    }
  }
  keyCache.delete(terminalId);
}

async function getTerminalKey(terminalId) {
  if (keyCache.has(terminalId)) return keyCache.get(terminalId);
  const { rows } = await opsDb.query(
    'SELECT public_key_pem, revoked FROM ops.terminals WHERE terminal_id = $1',
    [terminalId],
  );
  if (rows.length === 0 || rows[0].revoked) return null;
  const key = createPublicKey(rows[0].public_key_pem);
  keyCache.set(terminalId, key);
  return key;
}

// Verify an Ed25519 signature made by a registered terminal.
export async function verifyTerminalSignature(terminalId, bytes, signatureB64) {
  if (typeof signatureB64 !== 'string' || signatureB64.length === 0) {
    return { ok: false, reason: 'UNSIGNED' };
  }
  const key = await getTerminalKey(terminalId);
  if (!key) return { ok: false, reason: 'UNKNOWN_OR_REVOKED_TERMINAL' };
  let valid = false;
  try {
    valid = cryptoVerify(null, bytes, key, Buffer.from(signatureB64, 'base64'));
  } catch {
    valid = false;
  }
  return valid ? { ok: true } : { ok: false, reason: 'BAD_SIGNATURE' };
}

// Verify a small signed JSON request: { ...fields, terminal_id, timestamp, signature }.
// The timestamp check limits how long a captured request stays usable.
export async function verifySignedRequest(body) {
  const { signature, ...fields } = body ?? {};
  const ts = Date.parse(fields.timestamp);
  if (!Number.isFinite(ts) || Math.abs(Date.now() - ts) > config.requestClockSkewSeconds * 1000) {
    return { ok: false, reason: 'STALE_OR_MISSING_TIMESTAMP' };
  }
  return verifyTerminalSignature(fields.terminal_id, Buffer.from(canonicalize(fields)), signature);
}

export function clearKeyCache() {
  keyCache.clear();
}
