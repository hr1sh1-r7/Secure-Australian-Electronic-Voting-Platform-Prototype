import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import { api } from './routes.js';

const here = path.dirname(fileURLToPath(import.meta.url));

export function createApp() {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', false);

  // Security headers with a strict CSP: no inline scripts, same-origin only.
  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'"],
          imgSrc: ["'self'", 'data:'],
          connectSrc: ["'self'"],
          frameAncestors: ["'none'"],
          formAction: ["'self'"],
        },
      },
    }),
  );

  app.use(express.json({ limit: '2mb', strict: true }));
  app.use('/api', api);
  app.use('/admin', express.static(path.resolve(here, '..', 'public', 'admin')));
  app.get('/', (req, res) => res.redirect('/admin/'));

  app.use((req, res) => res.status(404).json({ error: 'NOT_FOUND' }));

  // Never leak stack traces or internal messages to the client.
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'INVALID_JSON' });
    if (err.type === 'entity.too.large') return res.status(413).json({ error: 'PAYLOAD_TOO_LARGE' });
    console.error('[ERROR]', err);
    res.status(500).json({ error: 'INTERNAL_ERROR' });
  });
  return app;
}
