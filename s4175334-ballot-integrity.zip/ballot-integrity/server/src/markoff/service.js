// SR-13: Atomic Single-Use Mark-off (Anti-Double Voting)
// Owner: Muzammil Malek (s4175334)
//
// Selected solution (Part 2): pessimistic row-level lock
// (SELECT ... FOR UPDATE NOWAIT) inside a SERIALIZABLE transaction.
//
// How double voting is prevented:
//  1. The voter's roll row is locked with FOR UPDATE NOWAIT. A second
//     terminal asking for the same voter at the same moment cannot wait for
//     the lock; it fails immediately with SQLSTATE 55P03 and gets HTTP 409.
//  2. The status only moves away from ELIGIBLE once, inside the lock.
//  3. SERIALIZABLE isolation turns any remaining anomaly into SQLSTATE
//     40001, which is also refused rather than allowed through.
//  4. Only after COMMIT is a single-use authorization token issued. It holds
//     a random jti and NO voter identity, and the jti is not stored here, so
//     the Ballot Store can never link a ballot back to a voter (SR-05).

import { randomUUID } from 'node:crypto';
import { SignJWT, jwtVerify } from 'jose';
import { rollDb, withTransaction } from '../db.js';
import { getKeys } from '../crypto/keys.js';
import { config } from '../config.js';
import { audit } from '../audit.js';

const LOCK_NOT_AVAILABLE = '55P03';
const SERIALIZATION_FAILURE = '40001';

export class MarkOffRefused extends Error {
  constructor(reason, status) {
    super(reason);
    this.reason = reason;
    this.status = status;
  }
}

// Mark a voter off the roll exactly once.
// mode = 'TOKEN_ISSUED' (online voting) or 'DECLARATION_ACCEPTED' (offline, SR-16).
export async function markOff({ electionId, voterId, terminalId, mode }) {
  const started = performance.now();
  try {
    await withTransaction(rollDb, 'SERIALIZABLE', async (client) => {
      const { rows } = await client.query(
        `SELECT status FROM roll.electoral_roll
         WHERE election_id = $1 AND voter_id = $2
         FOR UPDATE NOWAIT`,
        [electionId, voterId],
      );
      if (rows.length === 0) throw new MarkOffRefused('NOT_ON_ROLL', 404);
      if (rows[0].status !== 'ELIGIBLE') throw new MarkOffRefused('ALREADY_MARKED_OFF', 409);

      await client.query(
        `UPDATE roll.electoral_roll
         SET status = $3, marked_off_at = now(), marked_off_by_terminal = $4
         WHERE election_id = $1 AND voter_id = $2`,
        [electionId, voterId, mode, terminalId],
      );
    });
  } catch (err) {
    const ms = Math.round(performance.now() - started);
    if (err instanceof MarkOffRefused) {
      await audit(terminalId, 'MARKOFF_REFUSED', { electionId, reason: err.reason, ms });
      throw err;
    }
    if (err.code === LOCK_NOT_AVAILABLE || err.code === SERIALIZATION_FAILURE) {
      await audit(terminalId, 'MARKOFF_REFUSED', { electionId, reason: 'CONCURRENT_REQUEST', ms });
      throw new MarkOffRefused('CONCURRENT_REQUEST', 409);
    }
    throw err;
  }
  const ms = Math.round(performance.now() - started);
  // The audit entry records that a mark-off happened, not who voted how.
  await audit(terminalId, 'VOTER_MARKED_OFF', { electionId, mode, ms });
  return { ms };
}

// Issue a single-use ballot authorization token. RS256 to match SR-02.
export async function issueBallotToken(electionId) {
  const { tokenPrivateKey, tokenKid } = getKeys();
  const jti = randomUUID();
  const token = await new SignJWT({ eid: electionId, typ: 'ballot-authorization' })
    .setProtectedHeader({ alg: 'RS256', kid: tokenKid, typ: 'JWT' })
    .setIssuer(config.tokenIssuer)
    .setAudience(config.tokenAudience)
    .setJti(jti)
    .setIssuedAt()
    .setExpirationTime(`${config.tokenTtlSeconds}s`)
    .sign(tokenPrivateKey);
  return { token, expiresIn: config.tokenTtlSeconds };
}

export async function markOffAndAuthorize({ electionId, voterId, terminalId }) {
  const { ms } = await markOff({ electionId, voterId, terminalId, mode: 'TOKEN_ISSUED' });
  const { token, expiresIn } = await issueBallotToken(electionId);
  return { token, expiresIn, markOffMs: ms };
}

// Used by the Ballot Store. Algorithms are pinned to RS256, so 'alg: none'
// and HS256 key-confusion tokens are rejected (consistent with SR-02).
export async function verifyBallotToken(token, electionId) {
  const { tokenPublicKey } = getKeys();
  const { payload } = await jwtVerify(token, tokenPublicKey, {
    algorithms: ['RS256'],
    issuer: config.tokenIssuer,
    audience: config.tokenAudience,
    clockTolerance: 60,
    requiredClaims: ['jti', 'exp', 'iat'],
  });
  if (payload.typ !== 'ballot-authorization' || payload.eid !== electionId) {
    throw new Error('Token is not valid for this election');
  }
  if (!/^[0-9a-f-]{36}$/.test(payload.jti)) throw new Error('Malformed jti');
  return payload;
}
