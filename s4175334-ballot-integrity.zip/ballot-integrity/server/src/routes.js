// REST API for the Ballot Integrity subsystem. Owner: Muzammil Malek (s4175334)
import express from 'express';
import { config } from './config.js';
import { audit } from './audit.js';
import { opsDb, rollDb, ballotDb } from './db.js';
import { getKeys } from './crypto/keys.js';
import { getElection, closeElection } from './elections.js';
import { registerTerminal, verifySignedRequest, secretsMatch } from './terminals/registry.js';
import { markOffAndAuthorize, MarkOffRefused } from './markoff/service.js';
import { processBatch, BatchRejected } from './ballotstore/service.js';
import { runTally, publish, TallyError } from './tally/gate.js';
import { authorizeRequestSchema, registerSchema } from './ballotstore/schema.js';

export const api = express.Router();

// Placeholder officer authentication. Replace with the team's SR-01 (FIDO2)
// and SR-02 (strict RS256 JWT) middleware once merged.
function requireOfficer(req, res, next) {
  const header = req.get('authorization') ?? '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : '';
  if (!secretsMatch(token, config.adminApiToken)) {
    return res.status(401).json({ error: 'UNAUTHENTICATED' });
  }
  req.actor = 'election-officer';
  next();
}

const idPattern = /^[A-Za-z0-9_-]{3,40}$/;
const uuidPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

api.get('/health', (req, res) => res.json({ ok: true }));

// Public: what a terminal needs to show the ballot.
api.get('/elections/:id', async (req, res) => {
  if (!idPattern.test(req.params.id)) return res.status(400).json({ error: 'BAD_ID' });
  const e = await getElection(req.params.id);
  if (!e) return res.status(404).json({ error: 'UNKNOWN_ELECTION' });
  res.json({ election_id: e.election_id, name: e.name, candidates: e.candidates, status: e.status });
});

// Public key terminals pin to verify batch receipts (SR-14).
api.get('/keys/receipt', (req, res) => {
  const { receiptPublicKeyPem, receiptKid } = getKeys();
  res.json({ kid: receiptKid, algorithm: 'Ed25519', public_key_pem: receiptPublicKeyPem });
});

// SR-14: terminal enrolment. Needs the enrolment secret handed to the
// polling place out of band.
api.post('/terminals/register', async (req, res) => {
  if (!secretsMatch(req.get('x-enrolment-secret'), config.enrolmentSecret)) {
    await audit('unknown', 'TERMINAL_ENROLMENT_REFUSED', { ip: req.ip });
    return res.status(401).json({ error: 'BAD_ENROLMENT_SECRET' });
  }
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'MALFORMED_REQUEST' });
  try {
    await registerTerminal({
      terminalId: parsed.data.terminal_id,
      publicKeyPem: parsed.data.public_key_pem,
      pollingPlace: parsed.data.polling_place,
    });
  } catch (err) {
    return res.status(err.status ?? 400).json({ error: err.message });
  }
  await audit(parsed.data.terminal_id, 'TERMINAL_ENROLLED', { pollingPlace: parsed.data.polling_place });
  res.status(201).json({ enrolled: true });
});

// SR-13: mark off a voter and issue a single-use ballot authorization.
api.post('/markoff/authorize', async (req, res) => {
  const started = performance.now();
  const parsed = authorizeRequestSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: 'MALFORMED_REQUEST' });
  const sig = await verifySignedRequest(parsed.data);
  if (!sig.ok) {
    await audit(parsed.data.terminal_id, 'MARKOFF_REQUEST_REJECTED', { reason: sig.reason });
    return res.status(401).json({ error: sig.reason });
  }
  try {
    const result = await markOffAndAuthorize({
      electionId: parsed.data.election_id,
      voterId: parsed.data.voter_id,
      terminalId: parsed.data.terminal_id,
    });
    res.json({ token: result.token, expires_in: result.expiresIn, elapsed_ms: Math.round(performance.now() - started) });
  } catch (err) {
    if (err instanceof MarkOffRefused) {
      return res.status(err.status).json({ error: err.reason, elapsed_ms: Math.round(performance.now() - started) });
    }
    throw err;
  }
});

// SR-14 + SR-16: receive a signed batch of ballots.
api.post('/ballot-store/batches', async (req, res) => {
  try {
    const { receipt, duplicate, processingMs } = await processBatch(req.body);
    res.status(duplicate ? 200 : 201).json({ receipt, duplicate, processing_ms: processingMs });
  } catch (err) {
    if (err instanceof BatchRejected) {
      return res.status(err.status).json({ error: err.reason, detail: err.detail });
    }
    throw err;
  }
});

// Published results are public.
api.get('/results/:electionId', async (req, res) => {
  if (!idPattern.test(req.params.electionId)) return res.status(400).json({ error: 'BAD_ID' });
  const { rows } = await opsDb.query(
    'SELECT run_id, result, published_at FROM ops.published_results WHERE election_id = $1',
    [req.params.electionId],
  );
  if (!rows.length) return res.status(404).json({ error: 'NOT_PUBLISHED' });
  res.json(rows[0]);
});

// ---------------------------------------------------------- officer only ----

api.get('/admin/config', requireOfficer, (req, res) => res.json({ demoMode: config.demoMode }));

api.post('/admin/elections/:id/close', requireOfficer, async (req, res) => {
  if (!idPattern.test(req.params.id)) return res.status(400).json({ error: 'BAD_ID' });
  const closed = await closeElection(req.params.id);
  await audit(req.actor, 'ELECTION_CLOSE', { electionId: req.params.id, closed });
  res.status(closed ? 200 : 409).json({ closed });
});

// SR-15: run both engines and compare.
api.post('/admin/tally/:electionId/run', requireOfficer, async (req, res) => {
  if (!idPattern.test(req.params.electionId)) return res.status(400).json({ error: 'BAD_ID' });
  try {
    const result = await runTally(req.params.electionId, {
      actor: req.actor,
      simulateFault: req.body?.simulateFault === true,
    });
    res.json(result);
  } catch (err) {
    if (err instanceof TallyError) return res.status(err.status).json({ error: err.reason });
    throw err;
  }
});

api.post('/admin/tally/runs/:runId/publish', requireOfficer, async (req, res) => {
  if (!uuidPattern.test(req.params.runId)) return res.status(400).json({ error: 'BAD_ID' });
  try {
    res.json(await publish(req.params.runId, { actor: req.actor }));
  } catch (err) {
    if (err instanceof TallyError) return res.status(err.status).json({ error: err.reason });
    throw err;
  }
});

api.get('/admin/alerts', requireOfficer, async (req, res) => {
  const { rows } = await opsDb.query(
    'SELECT alert_id, raised_at, severity, subject, delivered_via FROM ops.alerts ORDER BY raised_at DESC LIMIT 20',
  );
  res.json(rows);
});

api.get('/admin/stats/:electionId', requireOfficer, async (req, res) => {
  if (!idPattern.test(req.params.electionId)) return res.status(400).json({ error: 'BAD_ID' });
  const e = await getElection(req.params.electionId);
  if (!e) return res.status(404).json({ error: 'UNKNOWN_ELECTION' });
  const [roll, ballots] = await Promise.all([
    rollDb.query(
      `SELECT count(*) FILTER (WHERE status <> 'ELIGIBLE')::int AS marked_off, count(*)::int AS enrolled
       FROM roll.electoral_roll WHERE election_id = $1`, [e.election_id]),
    ballotDb.query('SELECT count(*)::int AS ballots FROM ballot.ballots WHERE election_id = $1', [e.election_id]),
  ]);
  res.json({ ...e, ...roll.rows[0], ...ballots.rows[0] });
});
