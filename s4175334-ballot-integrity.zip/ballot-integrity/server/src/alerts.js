// Alerts to the State Electoral Officer (SR-15). Owner: Muzammil Malek (s4175334)
//
// The alert is recorded in ops.alerts and, if SEO_ALERT_WEBHOOK is set,
// POSTed to that webhook (e.g. a Teams/Slack/SOC endpoint) straight away.
// Delivery happens in seconds, well inside the 10-minute requirement.

import { randomUUID } from 'node:crypto';
import { opsDb } from './db.js';
import { config } from './config.js';
import { audit } from './audit.js';

export async function alertStateElectoralOfficer({ severity = 'CRITICAL', subject, detail }) {
  const alertId = randomUUID();
  let deliveredVia = 'dashboard';

  if (config.seoAlertWebhook) {
    try {
      const res = await fetch(config.seoAlertWebhook, {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ alertId, severity, subject, detail }),
        signal: AbortSignal.timeout(5000),
      });
      deliveredVia = res.ok ? 'dashboard+webhook' : `dashboard (webhook HTTP ${res.status})`;
    } catch (err) {
      deliveredVia = `dashboard (webhook failed: ${err.name})`;
    }
  }

  await opsDb.query(
    `INSERT INTO ops.alerts (alert_id, severity, subject, detail, delivered_via)
     VALUES ($1, $2, $3, $4, $5)`,
    [alertId, severity, subject, detail, deliveredVia],
  );
  await audit('system', 'SEO_ALERT_RAISED', { alertId, subject, deliveredVia });
  console.error(`[SEO ALERT ${severity}] ${subject}`);
  return { alertId, deliveredVia };
}
