// SR-15 Engine A: preferential count in JavaScript.
// Owner: Muzammil Malek (s4175334)
//
// Implements docs/counting-rules.md. Shares NO counting code with Engine B
// (tally-engine-b/engine_b.py, Python).

import { createHash } from 'node:crypto';

function hashCvr(electionId, cvr) {
  return createHash('sha384')
    .update(`${cvr.ballot_id}|${electionId}|${cvr.preferences.join(',')}`)
    .digest('hex');
}

function isFormal(preferences, candidateSet) {
  if (!Array.isArray(preferences) || preferences.length === 0) return false;
  return new Set(preferences).size === preferences.length && preferences.every((p) => candidateSet.has(p));
}

function pickExclusion(lowest, history) {
  let tied = lowest;
  // Walk back through earlier rounds, most recent first.
  for (let r = history.length - 1; r >= 0 && tied.length > 1; r--) {
    const counts = history[r];
    const min = Math.min(...tied.map((c) => counts[c]));
    tied = tied.filter((c) => counts[c] === min);
  }
  if (tied.length > 1) tied = [[...tied].sort().at(-1)];
  return tied[0];
}

export function countEngineA({ election_id, candidates, cvrs }) {
  const tampered = cvrs.filter((c) => hashCvr(election_id, c) !== c.cvr_hash).map((c) => c.ballot_id);
  if (tampered.length) return { error: 'INTEGRITY_FAILURE', ballot_ids: tampered.sort() };

  const candidateSet = new Set(candidates);
  const formal = cvrs.filter((c) => isFormal(c.preferences, candidateSet));
  const continuing = new Set(candidates);
  const rounds = [];
  const history = [];
  let winner = null;

  for (let roundNo = 1; ; roundNo++) {
    const counts = Object.fromEntries([...continuing].map((c) => [c, 0]));
    let exhausted = 0;
    for (const ballot of formal) {
      const choice = ballot.preferences.find((p) => continuing.has(p));
      if (choice === undefined) exhausted++;
      else counts[choice]++;
    }
    const total = Object.values(counts).reduce((a, b) => a + b, 0);
    const round = { round: roundNo, counts, exhausted, total, excluded: null, elected: null };
    rounds.push(round);

    const leader = Object.entries(counts).find(([, v]) => v * 2 > total);
    if (leader) {
      round.elected = leader[0];
      winner = leader[0];
      break;
    }
    if (total === 0) break;

    const min = Math.min(...Object.values(counts));
    const lowest = Object.keys(counts).filter((c) => counts[c] === min);
    const excluded = pickExclusion(lowest, history);
    round.excluded = excluded;
    history.push(counts);
    continuing.delete(excluded);
  }

  return {
    election_id,
    formal: formal.length,
    informal: cvrs.length - formal.length,
    winner,
    rounds,
  };
}
