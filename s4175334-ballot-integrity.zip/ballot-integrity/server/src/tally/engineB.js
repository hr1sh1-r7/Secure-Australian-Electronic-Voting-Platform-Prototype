// Runs the independent Python Engine B as a separate process (SR-15).
// Input goes in on stdin and the result comes back on stdout. No shell is
// involved, so nothing in the data can be interpreted as a command.
import { spawn } from 'node:child_process';
import { config } from '../config.js';

export function countEngineB(input) {
  return new Promise((resolve, reject) => {
    const child = spawn(config.pythonBin, ['-I', config.engineBPath], {
      stdio: ['pipe', 'pipe', 'pipe'],
      timeout: config.engineTimeoutMs,
    });
    const out = [];
    const err = [];
    child.stdout.on('data', (d) => out.push(d));
    child.stderr.on('data', (d) => err.push(d));
    child.on('error', reject);
    child.on('close', (code) => {
      if (code !== 0) {
        return reject(new Error(`Engine B exited with code ${code}: ${Buffer.concat(err).toString().slice(0, 500)}`));
      }
      try {
        resolve(JSON.parse(Buffer.concat(out).toString('utf8')));
      } catch (e) {
        reject(new Error('Engine B returned invalid JSON'));
      }
    });
    child.stdin.end(JSON.stringify(input));
  });
}
