// SR-15: Independent N-Version Recount Engine - publication gate
// Owner: Muzammil Malek (s4175334)
//
// Both engines count the same CVRs. Their full round-by-round outputs are
// compared. Any difference of 1 or more votes:
//   - marks the run BLOCKED (publish refuses it),
//   - writes an audit entry,
//   - alerts the State Electoral Officer immediately (well inside 10 minutes).

import { randomUUID, createHash } from 'node:crypto';
import { ballotDb, opsDb } from '../db.js';
import { getElection } from '../elections.js';
import { audit } from '../audit.js';
import { alertStateElectoralOfficer } from '../alerts.js';
import { config } from '../config.js';
import { canonicalize } from '../../../shared/canonical.js';
import { countEngineA } from './engineA.js';
import { countEngineB } from './engineB.js';

export class TallyError extends Error {
  constructor(reason, status) {
    super(reason);
    this.reason = reason;
    this.status = status;
  }
}

async function loadCvrs(electionId) {
  const { rows } = await ballotDb.query(
    'SELECT ballot_id, preferences, cvr_hash FROM ballot.ballots WHERE election_id = $1 ORDER BY ballot_id',
    [electionId],
  );
  return rows;
}

// Fingerprint of the exact CVR set counted. Publish recomputes it so that a
// run cannot be published if ballots changed after it was counted.
function cvrSetHash(cvrs) {
  const h = createHash('sha384');
  for (const c of cvrs) h.update(c.cvr_hash);
  return h.digest('hex');
}

// Describe where two engine outputs first differ.
export function findDiscrepancy(a, b) {
  if (a.error || b.error) {
    return a.error === b.error ? null : { type: 'ERROR_MISMATCH', engineA: a.error ?? null, engineB: b.error ?? null };
  }
  const rounds = Math.max(a.rounds?.length ?? 0, b.rounds?.length ?? 0);
  for (let i = 0; i < rounds; i++) {
    const ra = a.rounds[i];
    const rb = b.rounds[i];
    if (!ra || !rb) return { type: 'ROUND_COUNT_MISMATCH', round: i + 1 };
    const names = new Set([...Object.keys(ra.counts), ...Object.keys(rb.counts)]);
    const diffs = [];
    for (const n of [...names].sort()) {
      if (ra.counts[n] !== rb.counts[n]) diffs.push({ candidate: n, engineA: ra.counts[n] ?? null, engineB: rb.counts[n] ?? null });
    }
    if (diffs.length) return { type: 'VOTE_COUNT_MISMATCH', round: i + 1, diffs };
    if (canonicalize(ra) !== canonicalize(rb)) return { type: 'ROUND_DETAIL_MISMATCH', round: i + 1 };
  }
  if (canonicalize(a) !== canonicalize(b)) return { type: 'SUMMARY_MISMATCH' };
  return null;
}

// Demo only: simulate a defective second engine that counts one extra vote.
function injectFault(result) {
  const copy = structuredClone(result);
  const first = copy.rounds?.[0];
  if (first) {
    const candidate = Object.keys(first.counts).sort()[0];
    first.counts[candidate] += 1;
  }
  return copy;
}

export async function runTally(electionId, { actor, simulateFault = false } = {}) {
  const election = await getElection(electionId);
  if (!election) throw new TallyError('UNKNOWN_ELECTION', 404);
  if (simulateFault && !config.demoMode) throw new TallyError('FAULT_INJECTION_DISABLED', 403);

  const cvrs = await loadCvrs(electionId);
  const input = { election_id: electionId, candidates: election.candidates, cvrs };

  const started = performance.now();
  // Run both engines on the same input at the same time.
  const [engineA, rawB] = await Promise.all([Promise.resolve(countEngineA(input)), countEngineB(input)]);
  const engineB = simulateFault ? injectFault(rawB) : rawB;
  const ms = Math.round(performance.now() - started);

  const discrepancy = findDiscrepancy(engineA, engineB);
  const integrityFailure = Boolean(engineA.error || engineB.error);
  const matched = discrepancy === null && !integrityFailure;
  const runId = randomUUID();

  await opsDb.query(
    `INSERT INTO ops.tally_runs
       (run_id, election_id, cvr_count, cvr_set_hash, engine_a, engine_b, matched, discrepancy, status)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
    [runId, electionId, cvrs.length, cvrSetHash(cvrs), engineA, engineB, matched,
      discrepancy ?? (integrityFailure ? { type: 'INTEGRITY_FAILURE', engineA: engineA.error, engineB: engineB.error } : null),
      matched ? 'MATCHED' : 'BLOCKED'],
  );
  await audit(actor ?? 'system', matched ? 'TALLY_MATCHED' : 'TALLY_BLOCKED', { runId, electionId, cvrs: cvrs.length, ms, simulateFault });

  let alert = null;
  if (!matched) {
    alert = await alertStateElectoralOfficer({
      severity: 'CRITICAL',
      subject: `N-version count discrepancy: publication blocked for ${electionId}`,
      detail: { runId, electionId, discrepancy, integrityFailure },
    });
  }

  return { runId, electionId, matched, status: matched ? 'MATCHED' : 'BLOCKED', cvrCount: cvrs.length, ms, discrepancy, engineA, engineB, alert };
}

export async function publish(runId, { actor } = {}) {
  const { rows } = await opsDb.query('SELECT * FROM ops.tally_runs WHERE run_id = $1', [runId]);
  const run = rows[0];
  if (!run) throw new TallyError('UNKNOWN_RUN', 404);

  const refuse = async (reason, status = 409) => {
    await audit(actor ?? 'system', 'PUBLISH_REFUSED', { runId, reason });
    throw new TallyError(reason, status);
  };

  if (run.status === 'BLOCKED') await refuse('RUN_BLOCKED_BY_DISCREPANCY');
  if (run.status === 'PUBLISHED') await refuse('ALREADY_PUBLISHED');

  const election = await getElection(run.election_id);
  if (election.status !== 'CLOSED') await refuse('ELECTION_STILL_OPEN');

  const latest = await opsDb.query(
    'SELECT run_id FROM ops.tally_runs WHERE election_id = $1 ORDER BY started_at DESC LIMIT 1',
    [run.election_id],
  );
  if (latest.rows[0].run_id !== runId) await refuse('NOT_LATEST_RUN');

  const current = await loadCvrs(run.election_id);
  if (cvrSetHash(current) !== run.cvr_set_hash) await refuse('BALLOTS_CHANGED_SINCE_COUNT');

  const client = await opsDb.connect();
  try {
    await client.query('BEGIN');
    const ins = await client.query(
      `INSERT INTO ops.published_results (election_id, run_id, result)
       VALUES ($1, $2, $3) ON CONFLICT (election_id) DO NOTHING`,
      [run.election_id, runId, run.engine_a],
    );
    if (ins.rowCount === 0) throw new TallyError('ALREADY_PUBLISHED', 409);
    await client.query(`UPDATE ops.tally_runs SET status = 'PUBLISHED' WHERE run_id = $1`, [runId]);
    await client.query('COMMIT');
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
  await audit(actor ?? 'system', 'RESULT_PUBLISHED', { runId, electionId: run.election_id, winner: run.engine_a.winner });
  return { published: true, electionId: run.election_id, winner: run.engine_a.winner };
}
