// Officer console for SR-15. All server data is rendered with textContent,
// never innerHTML, so nothing from the API can inject markup (XSS).
'use strict';

const $ = (id) => document.getElementById(id);
let token = '';
let lastRun = null;

function el(tag, text, className) {
  const node = document.createElement(tag);
  if (text !== undefined && text !== null) node.textContent = String(text);
  if (className) node.className = className;
  return node;
}

async function api(path, options = {}) {
  const res = await fetch('/api' + path, {
    ...options,
    headers: { 'content-type': 'application/json', authorization: 'Bearer ' + token },
  });
  const body = await res.json().catch(() => ({}));
  return { ok: res.ok, status: res.status, body };
}

const electionId = () => $('electionId').value.trim();

function setPill(node, text, kind) {
  node.textContent = text;
  node.className = 'pill' + (kind ? ' ' + kind : '');
  node.hidden = false;
}

async function refresh() {
  const stats = await api('/admin/stats/' + encodeURIComponent(electionId()));
  if (!stats.ok) {
    $('electionName').textContent = 'Unknown election';
    return;
  }
  const s = stats.body;
  $('electionName').textContent = s.name;
  setPill($('electionStatus'), s.status, s.status === 'OPEN' ? 'ok' : '');
  $('statEnrolled').textContent = s.enrolled;
  $('statMarked').textContent = s.marked_off;
  $('statBallots').textContent = s.ballots;
  $('closeBtn').disabled = s.status !== 'OPEN';

  const alerts = await api('/admin/alerts');
  const list = $('alerts');
  list.replaceChildren();
  if (!alerts.body.length) list.append(el('li', 'No alerts raised.'));
  for (const a of alerts.body) {
    const li = el('li');
    li.append(el('time', new Date(a.raised_at).toLocaleString() + ' · ' + a.severity + ' · via ' + a.delivered_via));
    li.append(el('span', a.subject));
    list.append(li);
  }
}

function diffCells(run) {
  const cells = new Set();
  const d = run.discrepancy;
  if (d && d.type === 'VOTE_COUNT_MISMATCH') {
    for (const x of d.diffs) cells.add(d.round + ':' + x.candidate);
  }
  return cells;
}

function renderTable(result, diffs) {
  const wrap = el('div');
  if (result.error) {
    wrap.append(el('p', 'Refused to count: ' + result.error, 'message bad'));
    return wrap;
  }
  const candidates = Object.keys(result.rounds[0].counts).sort();
  const table = el('table');
  const head = el('tr');
  head.append(el('th', 'Candidate'));
  result.rounds.forEach((r) => head.append(el('th', 'R' + r.round)));
  table.append(head);
  for (const c of candidates) {
    const tr = el('tr');
    tr.append(el('td', c));
    for (const r of result.rounds) {
      const has = Object.prototype.hasOwnProperty.call(r.counts, c);
      let cls = has ? '' : 'out';
      if (r.elected === c) cls = 'win';
      if (diffs.has(r.round + ':' + c)) cls = 'diff';
      tr.append(el('td', has ? r.counts[c] : '—', cls));
    }
    table.append(tr);
  }
  const ex = el('tr');
  ex.append(el('td', 'Exhausted'));
  result.rounds.forEach((r) => ex.append(el('td', r.exhausted)));
  table.append(ex);
  wrap.append(table);
  wrap.append(el('p', 'Winner: ' + (result.winner ?? 'none') + ' · formal ' + result.formal + ', informal ' + result.informal, 'muted'));
  return wrap;
}

async function runCount() {
  $('runBtn').disabled = true;
  $('runMessage').textContent = 'Counting…';
  $('runMessage').className = 'message';
  const res = await api('/admin/tally/' + encodeURIComponent(electionId()) + '/run', {
    method: 'POST',
    body: JSON.stringify({ simulateFault: $('faultToggle').checked }),
  });
  $('runBtn').disabled = false;
  if (!res.ok) {
    $('runMessage').textContent = 'Count failed: ' + (res.body.error || res.status);
    $('runMessage').className = 'message bad';
    return;
  }
  lastRun = res.body;
  const matched = lastRun.status === 'MATCHED';
  setPill($('runBadge'), matched ? 'MATCHED' : 'BLOCKED', matched ? 'ok' : 'bad');
  if (matched) {
    $('runMessage').textContent = 'Both engines agree on every round (' + lastRun.cvrCount + ' ballots, ' + lastRun.ms + ' ms).';
    $('runMessage').className = 'message ok';
  } else {
    const d = lastRun.discrepancy || {};
    let detail = d.type || 'INTEGRITY_FAILURE';
    if (d.type === 'VOTE_COUNT_MISMATCH') {
      detail = 'round ' + d.round + ': ' + d.diffs.map((x) => x.candidate + ' A=' + x.engineA + ' B=' + x.engineB).join(', ');
    }
    $('runMessage').textContent = 'Publication blocked. Discrepancy in ' + detail + '. The State Electoral Officer has been alerted.';
    $('runMessage').className = 'message bad';
  }
  $('publishBtn').disabled = !matched;
  const diffs = diffCells(lastRun);
  $('tableA').replaceChildren(renderTable(lastRun.engineA, diffs));
  $('tableB').replaceChildren(renderTable(lastRun.engineB, diffs));
  $('comparison').hidden = false;
  refresh();
}

async function publishRun() {
  if (!lastRun) return;
  const res = await api('/admin/tally/runs/' + lastRun.runId + '/publish', { method: 'POST', body: '{}' });
  if (res.ok) {
    $('runMessage').textContent = 'Published. Winner: ' + res.body.winner + '.';
    $('runMessage').className = 'message ok';
    $('publishBtn').disabled = true;
  } else {
    $('runMessage').textContent = 'Publish refused: ' + res.body.error;
    $('runMessage').className = 'message bad';
  }
}

$('signinForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  token = $('token').value;
  const cfg = await api('/admin/config');
  if (!cfg.ok) {
    token = '';
    $('signinError').textContent = 'Sign-in failed.';
    return;
  }
  $('token').value = '';
  $('signin').hidden = true;
  $('console').hidden = false;
  $('faultWrap').hidden = !cfg.body.demoMode;
  refresh();
});
$('refreshBtn').addEventListener('click', refresh);
$('electionId').addEventListener('change', refresh);
$('runBtn').addEventListener('click', runCount);
$('publishBtn').addEventListener('click', publishRun);
$('closeBtn').addEventListener('click', async () => {
  if (!window.confirm('Close voting for ' + electionId() + '? Terminals must finish syncing first.')) return;
  await api('/admin/elections/' + encodeURIComponent(electionId()) + '/close', { method: 'POST', body: '{}' });
  refresh();
});
