// Creates the schema and demo data. Usage: npm run db:init [-- --reset]
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';

const here = path.dirname(fileURLToPath(import.meta.url));
const url = process.env.DATABASE_URL ?? 'postgres://postgres@localhost:5432/ballot_integrity';

export async function initDb(connectionString = url, { reset = false, seed = true } = {}) {
  const client = new pg.Client({ connectionString });
  await client.connect();
  try {
    if (reset) await client.query('DROP SCHEMA IF EXISTS roll, ballot, ops CASCADE');
    await client.query(fs.readFileSync(path.join(here, '..', 'db', 'schema.sql'), 'utf8'));
    if (seed) await client.query(fs.readFileSync(path.join(here, '..', 'db', 'seed.sql'), 'utf8'));
  } finally {
    await client.end();
  }
}

if (process.argv[1] === fileURLToPath(import.meta.url)) {
  await initDb(url, { reset: process.argv.includes('--reset') });
  console.log('Database ready.');
}
